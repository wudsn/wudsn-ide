// Generated automatically with "cito". Do not edit.
package net.sf.asap;

/**
 * ATR disk image reader.
 */
public abstract class AATR
{
	private int bytesPerSector;

	public final int getBytesPerSector()
	{
		return this.bytesPerSector;
	}

	/**
	 * Opens an ATR disk image.
	 * Returns <code>true</code> on success.
	 */
	public final boolean open()
	{
		byte[] header = new byte[6];
		if (!this.read(0, header, 6) || header[0] != -106 || header[1] != 2)
			return false;
		this.bytesPerSector = header[4] & 0xff | (header[5] & 0xff) << 8;
		this.sector4Offset = 400;
		switch (this.bytesPerSector) {
		case 128:
			break;
		case 256:
			if ((header[2] & 15) == 0)
				this.sector4Offset = 784;
			break;
		default:
			return false;
		}
		return true;
	}

	abstract boolean read(int offset, byte[] buffer, int length);

	final boolean readSector(int sectorNo, byte[] buffer, int length)
	{
		int offset;
		if (sectorNo < 4) {
			if (sectorNo < 1 || length > 128)
				return false;
			offset = (sectorNo << 7) - 112;
		}
		else
			offset = this.sector4Offset + (sectorNo - 4) * this.bytesPerSector;
		return this.read(offset, buffer, length);
	}
	private int sector4Offset;
}
