// Generated automatically with "cito". Do not edit.
package net.sf.asap;

interface FlashPackItemType
{
	int LITERAL = 0;
	int COPY_TWO_BYTES = 1;
	int COPY_THREE_BYTES = 2;
	int COPY_MANY_BYTES = 3;
	int SET_ADDRESS = 4;
	int END_OF_STREAM = 5;
}
