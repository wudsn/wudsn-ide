// Generated automatically with "cito". Do not edit.
package net.sf.asap;

class PokeyPair
{
	public PokeyPair()
	{
		int reg = 511;
		for (int i = 0; i < 511; i++) {
			reg = (((reg >> 5 ^ reg) & 1) << 8) + (reg >> 1);
			this.poly9Lookup[i] = (byte) reg;
		}
		reg = 131071;
		for (int i = 0; i < 16385; i++) {
			reg = (((reg >> 5 ^ reg) & 255) << 9) + (reg >> 8);
			this.poly17Lookup[i] = (byte) (reg >> 1);
		}
	}
	final Pokey basePokey = new Pokey();

	final int endFrame(int cycle)
	{
		this.basePokey.endFrame(this, cycle);
		if (this.extraPokeyMask != 0)
			this.extraPokey.endFrame(this, cycle);
		this.sampleOffset += cycle * this.sampleFactor;
		this.readySamplesStart = 0;
		this.readySamplesEnd = this.sampleOffset >> 20;
		this.sampleOffset &= 1048575;
		return this.readySamplesEnd;
	}
	final Pokey extraPokey = new Pokey();
	private int extraPokeyMask;

	/**
	 * Fills buffer with samples from <code>DeltaBuffer</code>.
	 */
	final int generate(byte[] buffer, int bufferOffset, int blocks, int format)
	{
		int i = this.readySamplesStart;
		int samplesEnd = this.readySamplesEnd;
		if (blocks < samplesEnd - i)
			samplesEnd = i + blocks;
		else
			blocks = samplesEnd - i;
		for (; i < samplesEnd; i++) {
			bufferOffset = this.basePokey.storeSample(buffer, bufferOffset, i, format);
			if (this.extraPokeyMask != 0)
				bufferOffset = this.extraPokey.storeSample(buffer, bufferOffset, i, format);
		}
		if (i == this.readySamplesEnd) {
			this.basePokey.accumulateTrailing(i);
			this.extraPokey.accumulateTrailing(i);
		}
		this.readySamplesStart = i;
		return blocks;
	}

	private static int getSampleFactor(int clock)
	{
		return (1445068800 + (clock >> 6)) / (clock >> 5);
	}

	final void initialize(boolean ntsc, boolean stereo)
	{
		this.extraPokeyMask = stereo ? 16 : 0;
		this.basePokey.initialize();
		this.extraPokey.initialize();
		this.sampleFactor = ntsc ? 25837 : 26075;
		this.sampleOffset = 0;
		this.readySamplesStart = 0;
		this.readySamplesEnd = 0;
	}

	final boolean isSilent()
	{
		return this.basePokey.isSilent() && this.extraPokey.isSilent();
	}

	final int peek(int addr, int cycle)
	{
		Pokey pokey = (addr & this.extraPokeyMask) != 0 ? this.extraPokey : this.basePokey;
		switch (addr & 15) {
		case 10:
			if (pokey.init)
				return 255;
			int i = cycle + pokey.polyIndex;
			if ((pokey.audctl & 128) != 0)
				return this.poly9Lookup[i % 511] & 0xff;
			i %= 131071;
			int j = i >> 3;
			i &= 7;
			return ((this.poly17Lookup[j] & 0xff) >> i) + ((this.poly17Lookup[j + 1] & 0xff) << 8 - i) & 255;
		case 14:
			return pokey.irqst;
		default:
			return 255;
		}
	}

	final int poke(int addr, int data, int cycle)
	{
		Pokey pokey = (addr & this.extraPokeyMask) != 0 ? this.extraPokey : this.basePokey;
		return pokey.poke(this, addr, data, cycle);
	}
	final byte[] poly17Lookup = new byte[16385];
	final byte[] poly9Lookup = new byte[511];
	int readySamplesEnd;
	int readySamplesStart;
	int sampleFactor;
	int sampleOffset;

	final void startFrame()
	{
		this.basePokey.startFrame();
		if (this.extraPokeyMask != 0)
			this.extraPokey.startFrame();
	}
}
