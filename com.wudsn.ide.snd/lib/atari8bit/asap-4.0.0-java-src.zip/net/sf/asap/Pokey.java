// Generated automatically with "cito". Do not edit.
package net.sf.asap;

class Pokey
{

	final void accumulateTrailing(int i)
	{
		this.iirAcc += this.deltaBuffer[i] + this.deltaBuffer[i + 1];
	}

	final void addDelta(PokeyPair pokeys, int cycle, int delta)
	{
		int i = cycle * pokeys.sampleFactor + pokeys.sampleOffset;
		int delta2 = (delta >> 16) * (i >> 4 & 65535);
		i >>= 20;
		this.deltaBuffer[i] += delta - delta2;
		this.deltaBuffer[i + 1] += delta2;
	}
	int audctl;
	final PokeyChannel[] channels = new PokeyChannel[] { new PokeyChannel(), new PokeyChannel(), new PokeyChannel(), new PokeyChannel() };

	final int checkIrq(int cycle, int nextEventCycle)
	{
		for (int i = 3;; i >>= 1) {
			int timerCycle = this.channels[i].timerCycle;
			if (cycle >= timerCycle) {
				this.irqst &= ~(i + 1);
				this.channels[i].timerCycle = 8388608;
			}
			else if (nextEventCycle > timerCycle)
				nextEventCycle = timerCycle;
			if (i == 0)
				break;
		}
		return nextEventCycle;
	}
	private final int[] deltaBuffer = new int[888];
	private int divCycles;

	final void endFrame(PokeyPair pokeys, int cycle)
	{
		this.generateUntilCycle(pokeys, cycle);
		this.polyIndex += cycle;
		int m = (this.audctl & 128) != 0 ? 237615 : 60948015;
		if (this.polyIndex >= 2 * m)
			this.polyIndex -= m;
		for (int i = 0; i < 4; i++) {
			int tickCycle = this.channels[i].tickCycle;
			if (tickCycle != 8388608)
				this.channels[i].tickCycle = tickCycle - cycle;
		}
	}

	/**
	 * Fills <code>DeltaBuffer</code> up to <code>cycleLimit</code> basing on current Audf/Audc/Audctl values.
	 */
	final void generateUntilCycle(PokeyPair pokeys, int cycleLimit)
	{
		for (;;) {
			int cycle = cycleLimit;
			for (int i = 0; i < 4; i++) {
				int tickCycle = this.channels[i].tickCycle;
				if (cycle > tickCycle)
					cycle = tickCycle;
			}
			if (cycle == cycleLimit)
				break;
			if (cycle == this.channels[2].tickCycle) {
				if ((this.audctl & 4) != 0 && this.channels[0].delta > 0 && this.channels[0].mute == 0)
					this.channels[0].slope(this, pokeys, cycle);
				this.channels[2].doTick(this, pokeys, cycle, 2);
			}
			if (cycle == this.channels[3].tickCycle) {
				if ((this.audctl & 8) != 0)
					this.channels[2].tickCycle = cycle + this.reloadCycles3;
				if ((this.audctl & 2) != 0 && this.channels[1].delta > 0 && this.channels[1].mute == 0)
					this.channels[1].slope(this, pokeys, cycle);
				this.channels[3].doTick(this, pokeys, cycle, 3);
			}
			if (cycle == this.channels[0].tickCycle) {
				if ((this.skctl & 136) == 8)
					this.channels[1].tickCycle = cycle + this.channels[1].periodCycles;
				this.channels[0].doTick(this, pokeys, cycle, 0);
			}
			if (cycle == this.channels[1].tickCycle) {
				if ((this.audctl & 16) != 0)
					this.channels[0].tickCycle = cycle + this.reloadCycles1;
				else if ((this.skctl & 8) != 0)
					this.channels[0].tickCycle = cycle + this.channels[0].periodCycles;
				this.channels[1].doTick(this, pokeys, cycle, 1);
			}
		}
	}
	private int iirAcc;
	boolean init;

	private void initMute(int cycle)
	{
		boolean init = this.init;
		int audctl = this.audctl;
		this.channels[0].setMute(init && (audctl & 64) == 0, 2, cycle);
		this.channels[1].setMute(init && (audctl & 80) != 80, 2, cycle);
		this.channels[2].setMute(init && (audctl & 32) == 0, 2, cycle);
		this.channels[3].setMute(init && (audctl & 40) != 40, 2, cycle);
	}

	final void initialize()
	{
		for (int i = 0; i < 4; i++)
			this.channels[i].initialize();
		this.audctl = 0;
		this.skctl = 3;
		this.irqst = 255;
		this.init = false;
		this.divCycles = 28;
		this.reloadCycles1 = 28;
		this.reloadCycles3 = 28;
		this.polyIndex = 60948015;
		this.iirAcc = 0;
		this.startFrame();
	}
	int irqst;

	final boolean isSilent()
	{
		for (int i = 0; i < 4; i++)
			if ((this.channels[i].audc & 15) != 0)
				return false;
		return true;
	}

	final void mute(int mask)
	{
		for (int i = 0; i < 4; i++)
			this.channels[i].setMute((mask & 1 << i) != 0, 4, 0);
	}

	final int poke(PokeyPair pokeys, int addr, int data, int cycle)
	{
		int nextEventCycle = 8388608;
		switch (addr & 15) {
		case 0:
			if (data == this.channels[0].audf)
				break;
			this.generateUntilCycle(pokeys, cycle);
			this.channels[0].audf = data;
			switch (this.audctl & 80) {
			case 0:
				this.channels[0].periodCycles = this.divCycles * (data + 1);
				break;
			case 16:
				this.channels[1].periodCycles = this.divCycles * (data + (this.channels[1].audf << 8) + 1);
				this.reloadCycles1 = this.divCycles * (data + 1);
				this.channels[1].muteUltrasound(cycle);
				break;
			case 64:
				this.channels[0].periodCycles = data + 4;
				break;
			case 80:
				this.channels[1].periodCycles = data + (this.channels[1].audf << 8) + 7;
				this.reloadCycles1 = data + 4;
				this.channels[1].muteUltrasound(cycle);
				break;
			}
			this.channels[0].muteUltrasound(cycle);
			break;
		case 1:
			this.channels[0].setAudc(this, pokeys, data, cycle);
			break;
		case 2:
			if (data == this.channels[1].audf)
				break;
			this.generateUntilCycle(pokeys, cycle);
			this.channels[1].audf = data;
			switch (this.audctl & 80) {
			case 0:
			case 64:
				this.channels[1].periodCycles = this.divCycles * (data + 1);
				break;
			case 16:
				this.channels[1].periodCycles = this.divCycles * (this.channels[0].audf + (data << 8) + 1);
				break;
			case 80:
				this.channels[1].periodCycles = this.channels[0].audf + (data << 8) + 7;
				break;
			}
			this.channels[1].muteUltrasound(cycle);
			break;
		case 3:
			this.channels[1].setAudc(this, pokeys, data, cycle);
			break;
		case 4:
			if (data == this.channels[2].audf)
				break;
			this.generateUntilCycle(pokeys, cycle);
			this.channels[2].audf = data;
			switch (this.audctl & 40) {
			case 0:
				this.channels[2].periodCycles = this.divCycles * (data + 1);
				break;
			case 8:
				this.channels[3].periodCycles = this.divCycles * (data + (this.channels[3].audf << 8) + 1);
				this.reloadCycles3 = this.divCycles * (data + 1);
				this.channels[3].muteUltrasound(cycle);
				break;
			case 32:
				this.channels[2].periodCycles = data + 4;
				break;
			case 40:
				this.channels[3].periodCycles = data + (this.channels[3].audf << 8) + 7;
				this.reloadCycles3 = data + 4;
				this.channels[3].muteUltrasound(cycle);
				break;
			}
			this.channels[2].muteUltrasound(cycle);
			break;
		case 5:
			this.channels[2].setAudc(this, pokeys, data, cycle);
			break;
		case 6:
			if (data == this.channels[3].audf)
				break;
			this.generateUntilCycle(pokeys, cycle);
			this.channels[3].audf = data;
			switch (this.audctl & 40) {
			case 0:
			case 32:
				this.channels[3].periodCycles = this.divCycles * (data + 1);
				break;
			case 8:
				this.channels[3].periodCycles = this.divCycles * (this.channels[2].audf + (data << 8) + 1);
				break;
			case 40:
				this.channels[3].periodCycles = this.channels[2].audf + (data << 8) + 7;
				break;
			}
			this.channels[3].muteUltrasound(cycle);
			break;
		case 7:
			this.channels[3].setAudc(this, pokeys, data, cycle);
			break;
		case 8:
			if (data == this.audctl)
				break;
			this.generateUntilCycle(pokeys, cycle);
			this.audctl = data;
			this.divCycles = (data & 1) != 0 ? 114 : 28;
			switch (data & 80) {
			case 0:
				this.channels[0].periodCycles = this.divCycles * (this.channels[0].audf + 1);
				this.channels[1].periodCycles = this.divCycles * (this.channels[1].audf + 1);
				break;
			case 16:
				this.channels[0].periodCycles = this.divCycles << 8;
				this.channels[1].periodCycles = this.divCycles * (this.channels[0].audf + (this.channels[1].audf << 8) + 1);
				this.reloadCycles1 = this.divCycles * (this.channels[0].audf + 1);
				break;
			case 64:
				this.channels[0].periodCycles = this.channels[0].audf + 4;
				this.channels[1].periodCycles = this.divCycles * (this.channels[1].audf + 1);
				break;
			case 80:
				this.channels[0].periodCycles = 256;
				this.channels[1].periodCycles = this.channels[0].audf + (this.channels[1].audf << 8) + 7;
				this.reloadCycles1 = this.channels[0].audf + 4;
				break;
			}
			this.channels[0].muteUltrasound(cycle);
			this.channels[1].muteUltrasound(cycle);
			switch (data & 40) {
			case 0:
				this.channels[2].periodCycles = this.divCycles * (this.channels[2].audf + 1);
				this.channels[3].periodCycles = this.divCycles * (this.channels[3].audf + 1);
				break;
			case 8:
				this.channels[2].periodCycles = this.divCycles << 8;
				this.channels[3].periodCycles = this.divCycles * (this.channels[2].audf + (this.channels[3].audf << 8) + 1);
				this.reloadCycles3 = this.divCycles * (this.channels[2].audf + 1);
				break;
			case 32:
				this.channels[2].periodCycles = this.channels[2].audf + 4;
				this.channels[3].periodCycles = this.divCycles * (this.channels[3].audf + 1);
				break;
			case 40:
				this.channels[2].periodCycles = 256;
				this.channels[3].periodCycles = this.channels[2].audf + (this.channels[3].audf << 8) + 7;
				this.reloadCycles3 = this.channels[2].audf + 4;
				break;
			}
			this.channels[2].muteUltrasound(cycle);
			this.channels[3].muteUltrasound(cycle);
			this.initMute(cycle);
			break;
		case 9:
			for (int i = 0; i < 4; i++)
				this.channels[i].doStimer(cycle);
			break;
		case 14:
			this.irqst |= data ^ 255;
			for (int i = 3;; i >>= 1) {
				if ((data & this.irqst & i + 1) != 0) {
					if (this.channels[i].timerCycle == 8388608) {
						int t = this.channels[i].tickCycle;
						while (t < cycle)
							t += this.channels[i].periodCycles;
						this.channels[i].timerCycle = t;
						if (nextEventCycle > t)
							nextEventCycle = t;
					}
				}
				else
					this.channels[i].timerCycle = 8388608;
				if (i == 0)
					break;
			}
			break;
		case 15:
			if (data == this.skctl)
				break;
			this.generateUntilCycle(pokeys, cycle);
			this.skctl = data;
			boolean init = (data & 3) == 0;
			if (this.init && !init)
				this.polyIndex = ((this.audctl & 128) != 0 ? 237614 : 60948014) - cycle;
			this.init = init;
			this.initMute(cycle);
			this.channels[2].setMute((data & 16) != 0, 8, cycle);
			this.channels[3].setMute((data & 16) != 0, 8, cycle);
			break;
		default:
			break;
		}
		return nextEventCycle;
	}
	int polyIndex;
	private int reloadCycles1;
	private int reloadCycles3;
	private int skctl;

	final void startFrame()
	{
		clear(this.deltaBuffer);
	}

	final int storeSample(byte[] buffer, int bufferOffset, int i, int format)
	{
		this.iirAcc += this.deltaBuffer[i] - (this.iirAcc * 3 >> 10);
		int sample = this.iirAcc >> 11;
		if (sample < -32767)
			sample = -32767;
		else if (sample > 32767)
			sample = 32767;
		switch (format) {
		case ASAPSampleFormat.U8:
			buffer[bufferOffset++] = (byte) ((sample >> 8) + 128);
			break;
		case ASAPSampleFormat.S16_L_E:
			buffer[bufferOffset++] = (byte) sample;
			buffer[bufferOffset++] = (byte) (sample >> 8);
			break;
		case ASAPSampleFormat.S16_B_E:
			buffer[bufferOffset++] = (byte) (sample >> 8);
			buffer[bufferOffset++] = (byte) sample;
			break;
		}
		return bufferOffset;
	}
	private static void clear(int[] array)
	{
		for (int i = 0; i < array.length; i++)
			array[i] = 0;
	}
}
