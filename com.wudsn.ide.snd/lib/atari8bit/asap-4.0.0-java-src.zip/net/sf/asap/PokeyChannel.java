// Generated automatically with "cito". Do not edit.
package net.sf.asap;

class PokeyChannel
{
	int audc;
	int audf;
	int delta;

	final void doStimer(int cycle)
	{
		if (this.tickCycle != 8388608)
			this.tickCycle = cycle + this.periodCycles;
	}

	final void doTick(Pokey pokey, PokeyPair pokeys, int cycle, int ch)
	{
		this.tickCycle += this.periodCycles;
		int audc = this.audc;
		if ((audc & 176) == 160)
			this.out ^= 1;
		else if ((audc & 16) != 0 || pokey.init)
			return;
		else {
			int poly = cycle + pokey.polyIndex - ch;
			if (audc < 128 && (1706902752 & 1 << poly % 31) == 0)
				return;
			if ((audc & 32) != 0)
				this.out ^= 1;
			else {
				int newOut;
				if ((audc & 64) != 0)
					newOut = 21360 >> poly % 15;
				else if (pokey.audctl < 128) {
					poly %= 131071;
					newOut = (pokeys.poly17Lookup[poly >> 3] & 0xff) >> (poly & 7);
				}
				else
					newOut = pokeys.poly9Lookup[poly % 511] & 0xff;
				newOut &= 1;
				if (this.out == newOut)
					return;
				this.out = newOut;
			}
		}
		this.slope(pokey, pokeys, cycle);
	}

	final void endFrame(int cycle)
	{
		if (this.timerCycle != 8388608)
			this.timerCycle -= cycle;
	}

	final void initialize()
	{
		this.audf = 0;
		this.audc = 0;
		this.periodCycles = 28;
		this.tickCycle = 8388608;
		this.timerCycle = 8388608;
		this.mute = 1;
		this.out = 0;
		this.delta = 0;
	}
	int mute;

	final void muteUltrasound(int cycle)
	{
		this.setMute(this.periodCycles <= 112 && (this.audc & 176) == 160, 1, cycle);
	}
	private int out;
	int periodCycles;

	final void setAudc(Pokey pokey, PokeyPair pokeys, int data, int cycle)
	{
		if (this.audc == data)
			return;
		pokey.generateUntilCycle(pokeys, cycle);
		this.audc = data;
		if ((data & 16) != 0) {
			data = (data & 15) << 20;
			if ((this.mute & 4) == 0)
				pokey.addDelta(pokeys, cycle, this.delta > 0 ? data - this.delta : data);
			this.delta = data;
		}
		else {
			data = (data & 15) << 20;
			this.muteUltrasound(cycle);
			if (this.delta > 0) {
				if ((this.mute & 4) == 0)
					pokey.addDelta(pokeys, cycle, data - this.delta);
				this.delta = data;
			}
			else
				this.delta = -data;
		}
	}

	final void setMute(boolean enable, int mask, int cycle)
	{
		if (enable) {
			this.mute |= mask;
			this.tickCycle = 8388608;
		}
		else {
			this.mute &= ~mask;
			if (this.mute == 0 && this.tickCycle == 8388608)
				this.tickCycle = cycle;
		}
	}

	final void slope(Pokey pokey, PokeyPair pokeys, int cycle)
	{
		this.delta = -this.delta;
		pokey.addDelta(pokeys, cycle, this.delta);
	}
	int tickCycle;
	int timerCycle;
}
