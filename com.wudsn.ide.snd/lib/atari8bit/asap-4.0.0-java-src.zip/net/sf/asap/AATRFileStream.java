// Generated automatically with "cito". Do not edit.
package net.sf.asap;

/**
 * Contents of a file on an ATR disk image.
 */
public class AATRFileStream
{
	private AATR disk;
	private int fileType;
	private int firstSector;

	/**
	 * Returns the disk image containing this file.
	 */
	public final AATR getDisk()
	{
		return this.disk;
	}

	/**
	 * Returns the length of the open file.
	 */
	public final int getLength()
	{
		int position = this.getPosition();
		int length = position + this.read(null, 0, 2147483647 - position);
		this.setPosition(position);
		return length;
	}

	/**
	 * Returns the current position in the open file.
	 */
	public final int getPosition()
	{
		return this.position;
	}
	private int nextSector;

	/**
	 * Opens a file..
	 * @param directory Directory iterator pointing at the file to open.
	 */
	public final void open(AATRDirectory directory)
	{
		this.disk = directory.disk;
		this.firstSector = directory.getEntryFirstSector();
		this.fileType = directory.getEntryType() & 6;
		this.rewind();
	}
	private int position;

	/**
	 * Reads from the open file.
	 * Returns the number of bytes read.
	 * @param buffer Destination buffer.
	 * @param offset Start offset in buffer at which the data is written.
	 * @param length Maximum number of bytes to read.
	 */
	public final int read(byte[] buffer, int offset, int length)
	{
		int totalRead = 0;
		int bytesPerSector = this.disk.getBytesPerSector();
		while (length > 0) {
			int got;
			for (;;) {
				got = this.sector[bytesPerSector - 1] & 0xff;
				if (this.fileType == 0) {
					if (got < 128)
						got = 125;
					else
						got -= 128;
				}
				else if (got > bytesPerSector)
					return -1;
				got -= this.sectorOffset;
				if (got > 0)
					break;
				if (!this.disk.readSector(this.nextSector, this.sector, bytesPerSector))
					return totalRead;
				this.sectorOffset = 0;
				int sectorHi = this.sector[bytesPerSector - 3] & 0xff;
				if (this.fileType != 6)
					sectorHi &= 3;
				this.nextSector = sectorHi << 8 | this.sector[bytesPerSector - 2] & 0xff;
			}
			if (got > length)
				got = length;
			if (buffer != null)
				System.arraycopy(this.sector, this.sectorOffset, buffer, offset + totalRead, got);
			this.position += got;
			this.sectorOffset += got;
			totalRead += got;
			length -= got;
		}
		return totalRead;
	}

	private void rewind()
	{
		this.position = 0;
		this.nextSector = this.firstSector;
		this.sectorOffset = 255;
	}
	private final byte[] sector = new byte[256];
	private int sectorOffset;

	/**
	 * Sets the current position in the open file.
	 * Returns <code>true</code> on success.
	 * @param position Requested position.
	 */
	public final boolean setPosition(int position)
	{
		int toSkip = position - this.position;
		if (toSkip >= 0)
			return this.read(null, 0, toSkip) == toSkip;
		this.rewind();
		return this.read(null, 0, position) == position;
	}
}
