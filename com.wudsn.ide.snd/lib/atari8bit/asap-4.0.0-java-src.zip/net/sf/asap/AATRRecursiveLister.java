// Generated automatically with "cito". Do not edit.
package net.sf.asap;

/**
 * Iterator over all files on an ATR disk image.
 */
public class AATRRecursiveLister
{
	private int depth;
	private final AATRDirectory[] directories = new AATRDirectory[] { new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory(), new AATRDirectory() };
	private String directoryPath;
	private String filePath;

	/**
	 * Returns the directory iterator pointing at the file found by <code>NextFile</code>.
	 */
	public final AATRDirectory getDirectory()
	{
		return this.directories[this.depth];
	}

	/**
	 * Advances to the next file.
	 * Returns the full path of the file or <code>null</code> if no more files found.
	 */
	public final String nextFile()
	{
		for (;;) {
			AATRDirectory directory = this.directories[this.depth];
			String filename = directory.nextEntry();
			if (filename == null) {
				if (this.depth == 0)
					return null;
				int i = this.directoryPath.length() - 1;
				while (--i >= 0 && this.directoryPath.charAt(i) != 47) {
				}
				this.directoryPath = this.directoryPath.substring(0, 0 + i + 1);
				this.depth--;
			}
			else if (directory.isEntryDirectory()) {
				if (this.depth >= 19)
					continue;
				this.directoryPath += filename;
				this.directoryPath += "/";
				this.directories[++this.depth].open(directory);
			}
			else {
				this.filePath = this.directoryPath;
				this.filePath += filename;
				return this.filePath;
			}
		}
	}

	/**
	 * Opens a disk image.
	 * @param disk The disk image to list files on.
	 */
	public final void open(AATR disk)
	{
		this.directories[0].openRoot(disk);
		this.depth = 0;
		this.directoryPath = "";
	}
}
