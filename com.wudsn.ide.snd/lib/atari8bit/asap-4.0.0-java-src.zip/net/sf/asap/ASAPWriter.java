// Generated automatically with "cito". Do not edit.
package net.sf.asap;

/**
 * Static methods for writing modules in different formats.
 */
public class ASAPWriter
{

	/**
	 * Writes text representation of the given duration.
	 * Returns the number of bytes written to <code>result</code>.
	 * @param result The output buffer.
	 * @param value Number of milliseconds.
	 */
	public static int durationToString(byte[] result, int value)
	{
		if (!ASAPWriter.secondsToString(result, 0, value))
			return 0;
		value %= 1000;
		if (value == 0)
			return 5;
		result[5] = 46;
		ASAPWriter.twoDigitsToString(result, 6, value / 10);
		value %= 10;
		if (value == 0)
			return 8;
		result[8] = (byte) (48 + value);
		return 9;
	}

	private static int formatXexInfoText(byte[] dest, int destLen, int endColumn, String src, boolean author)
	{
		int srcLen = src.length();
		for (int srcOffset = 0; srcOffset < srcLen;) {
			int c = src.charAt(srcOffset++);
			if (c == 32) {
				if (author && srcOffset < srcLen && src.charAt(srcOffset) == 38) {
					int authorLen;
					for (authorLen = 1; srcOffset + authorLen < srcLen; authorLen++) {
						if (src.charAt(srcOffset + authorLen) == 32 && srcOffset + authorLen + 1 < srcLen && src.charAt(srcOffset + authorLen + 1) == 38)
							break;
					}
					if (authorLen <= 32 && destLen % 32 + 1 + authorLen > 32) {
						destLen = ASAPWriter.padXexInfo(dest, destLen, 1);
						continue;
					}
				}
				int wordLen;
				for (wordLen = 0; srcOffset + wordLen < srcLen && src.charAt(srcOffset + wordLen) != 32; wordLen++) {
				}
				if (wordLen <= 32 && destLen % 32 + 1 + wordLen > 32) {
					destLen = ASAPWriter.padXexInfo(dest, destLen, 0);
					continue;
				}
			}
			dest[destLen++] = (byte) c;
		}
		return ASAPWriter.padXexInfo(dest, destLen, endColumn);
	}

	/**
	 * Enumerates possible file types the given module can be written as.
	 * Returns the number of extensions written to <code>exts</code>.
	 * @param exts Receives filename extensions without the leading dot.
	 * @param info File information.
	 * @param module Contents of the file.
	 * @param moduleLen Length of the file.
	 */
	public static int getSaveExts(String[] exts, ASAPInfo info, byte[] module, int moduleLen)
	{
		int i = 0;
		switch (info.type) {
		case ASAPModuleType.SAP_B:
		case ASAPModuleType.SAP_C:
			exts[i++] = "sap";
			String ext = info.getOriginalModuleExt(module, moduleLen);
			if (ext != null)
				exts[i++] = ext;
			exts[i++] = "xex";
			break;
		case ASAPModuleType.SAP_D:
			exts[i++] = "sap";
			if (info.getPlayerRateScanlines() == 312)
				exts[i++] = "xex";
			break;
		case ASAPModuleType.SAP_S:
			exts[i++] = "sap";
			break;
		default:
			exts[i++] = info.getOriginalModuleExt(module, moduleLen);
			exts[i++] = "sap";
			exts[i++] = "xex";
			break;
		}
		return i;
	}
	/**
	 * Maximum length of text representation of a duration.
	 * Corresponds to the longest format which is <code>"mm:ss.xxx"</code>.
	 */
	public static final int MAX_DURATION_LENGTH = 9;
	public static final int MAX_SAVE_EXTS = 3;
	byte[] output;
	private int outputEnd;
	int outputOffset;

	private static int padXexInfo(byte[] dest, int offset, int endColumn)
	{
		while (offset % 32 != endColumn)
			dest[offset++] = 32;
		return offset;
	}

	private static boolean secondsToString(byte[] result, int offset, int value)
	{
		if (value < 0 || value >= 6000000)
			return false;
		value /= 1000;
		ASAPWriter.twoDigitsToString(result, offset, value / 60);
		result[offset + 2] = 58;
		ASAPWriter.twoDigitsToString(result, offset + 3, value % 60);
		return true;
	}

	public final void setOutput(byte[] output, int startIndex, int endIndex)
	{
		this.output = output;
		this.outputOffset = startIndex;
		this.outputEnd = endIndex;
	}

	private static void twoDigitsToString(byte[] result, int offset, int value)
	{
		result[offset] = (byte) (48 + value / 10);
		result[offset + 1] = (byte) (48 + value % 10);
	}

	/**
	 * Writes the given module in a possibly different file format.
	 * @param targetFilename Output filename, used to determine the format.
	 * @param info File information got from the source file with data updated for the output file.
	 * @param module Contents of the source file.
	 * @param moduleLen Length of the source file.
	 * @param tag Display information (xex output only).
	 */
	public final int write(String targetFilename, ASAPInfo info, byte[] module, int moduleLen, boolean tag) throws Exception
	{
		int destExt = ASAPInfo.getPackedExt(targetFilename);
		switch (destExt) {
		case 7364979:
			this.writeExecutable(null, info, module, moduleLen);
			return this.outputOffset;
		case 7890296:
			{
				int[] initAndPlayer = new int[2];
				this.writeExecutable(initAndPlayer, info, module, moduleLen);
				switch (info.type) {
				case ASAPModuleType.SAP_D:
					if (info.getPlayerRateScanlines() != 312)
						throw new Exception("Impossible conversion");
					this.writeBytes(getBinaryResource("xexd.obx", 117), 2, 117);
					this.writeWord(initAndPlayer[0]);
					if (initAndPlayer[1] < 0) {
						this.writeByte(96);
						this.writeByte(96);
						this.writeByte(96);
					}
					else {
						this.writeByte(76);
						this.writeWord(initAndPlayer[1]);
					}
					this.writeByte(info.getDefaultSong());
					break;
				case ASAPModuleType.SAP_S:
					throw new Exception("Impossible conversion");
				default:
					this.writeBytes(getBinaryResource("xexb.obx", 183), 2, 183);
					this.writeWord(initAndPlayer[0]);
					this.writeByte(76);
					this.writeWord(initAndPlayer[1]);
					this.writeByte(info.getDefaultSong());
					int fastplay = info.getPlayerRateScanlines();
					this.writeByte(fastplay & 1);
					this.writeByte((fastplay >> 1) % 156);
					this.writeByte((fastplay >> 1) % 131);
					this.writeByte(fastplay / 312);
					this.writeByte(fastplay / 262);
					break;
				}
				if (tag)
					this.writeXexInfo(info);
				this.writeWord(736);
				this.writeWord(737);
				this.writeWord(tag ? 256 : 292);
				FlashPack flashPack = new FlashPack();
				flashPack.compress(this);
				return this.outputOffset;
			}
		default:
			String possibleExt = info.getOriginalModuleExt(module, moduleLen);
			if (possibleExt != null) {
				int packedPossibleExt = ASAPInfo.packExt(possibleExt);
				if (destExt == packedPossibleExt || destExt == 3698036 && packedPossibleExt == 6516084) {
					this.writeNative(info, module, moduleLen);
					return this.outputOffset;
				}
			}
			throw new Exception("Impossible conversion");
		}
	}

	final void writeByte(int value) throws Exception
	{
		if (this.outputOffset >= this.outputEnd)
			throw new Exception("Output full");
		this.output[this.outputOffset++] = (byte) value;
	}

	final void writeBytes(byte[] array, int startIndex, int endIndex) throws Exception
	{
		int length = endIndex - startIndex;
		if (this.outputOffset + length > this.outputEnd)
			throw new Exception("Output full");
		System.arraycopy(array, startIndex, this.output, this.outputOffset, length);
		this.outputOffset += length;
	}

	private void writeCmcInit(int[] initAndPlayer, ASAPInfo info) throws Exception
	{
		if (initAndPlayer == null)
			return;
		this.writeWord(4064);
		this.writeWord(4080);
		this.writeByte(72);
		int music = info.getMusicAddress();
		this.writeByte(162);
		this.writeByte(music & 255);
		this.writeByte(160);
		this.writeByte(music >> 8);
		this.writeByte(169);
		this.writeByte(112);
		this.writeByte(32);
		this.writeWord(initAndPlayer[1] + 3);
		this.writePlaTaxLda0();
		this.writeByte(76);
		this.writeWord(initAndPlayer[1] + 3);
		initAndPlayer[0] = 4064;
		initAndPlayer[1] += 6;
	}

	private void writeDec(int value) throws Exception
	{
		if (value >= 10) {
			this.writeDec(value / 10);
			value %= 10;
		}
		this.writeByte(48 + value);
	}

	private void writeDecSapTag(String tag, int value) throws Exception
	{
		this.writeString(tag);
		this.writeDec(value);
		this.writeByte(13);
		this.writeByte(10);
	}

	final void writeExecutable(int[] initAndPlayer, ASAPInfo info, byte[] module, int moduleLen) throws Exception
	{
		byte[] playerRoutine = ASAP6502.getPlayerRoutine(info);
		int player = -1;
		int playerLastByte = -1;
		int music = info.getMusicAddress();
		if (playerRoutine != null) {
			player = ASAPInfo.getWord(playerRoutine, 2);
			playerLastByte = ASAPInfo.getWord(playerRoutine, 4);
			if (music <= playerLastByte)
				throw new Exception("Module address conflicts with the player routine");
		}
		int startAddr;
		switch (info.type) {
		case ASAPModuleType.SAP_B:
			this.writeExecutableFromSap(initAndPlayer, info, 66, module, moduleLen);
			break;
		case ASAPModuleType.SAP_C:
			this.writeExecutableFromSap(initAndPlayer, info, 67, module, moduleLen);
			this.writeCmcInit(initAndPlayer, info);
			break;
		case ASAPModuleType.SAP_D:
			this.writeExecutableFromSap(initAndPlayer, info, 68, module, moduleLen);
			break;
		case ASAPModuleType.SAP_S:
			this.writeExecutableFromSap(initAndPlayer, info, 83, module, moduleLen);
			break;
		case ASAPModuleType.CMC:
		case ASAPModuleType.CM3:
		case ASAPModuleType.CMR:
		case ASAPModuleType.CMS:
			this.writeExecutableHeader(initAndPlayer, info, 67, -1, player);
			this.writeWord(65535);
			this.writeBytes(module, 2, moduleLen);
			this.writeBytes(playerRoutine, 2, playerLastByte - player + 7);
			this.writeCmcInit(initAndPlayer, info);
			break;
		case ASAPModuleType.DLT:
			startAddr = this.writeExecutableHeaderForSongPos(initAndPlayer, info, player, 5, 7, 259);
			if (moduleLen == 11270) {
				this.writeBytes(module, 0, 4);
				this.writeWord(19456);
				this.writeBytes(module, 6, moduleLen);
				this.writeByte(0);
			}
			else
				this.writeBytes(module, 0, moduleLen);
			this.writeWord(startAddr);
			this.writeWord(playerLastByte);
			if (info.getSongs() != 1) {
				this.writeBytes(info.songPos, 0, info.getSongs());
				this.writeByte(170);
				this.writeByte(188);
				this.writeWord(startAddr);
			}
			else {
				this.writeByte(160);
				this.writeByte(0);
			}
			this.writeByte(76);
			this.writeWord(player + 256);
			this.writeBytes(playerRoutine, 6, playerLastByte - player + 7);
			break;
		case ASAPModuleType.MPT:
			startAddr = this.writeExecutableHeaderForSongPos(initAndPlayer, info, player, 13, 17, 3);
			this.writeBytes(module, 0, moduleLen);
			this.writeWord(startAddr);
			this.writeWord(playerLastByte);
			if (info.getSongs() != 1) {
				this.writeBytes(info.songPos, 0, info.getSongs());
				this.writeByte(72);
			}
			this.writeByte(160);
			this.writeByte(music & 255);
			this.writeByte(162);
			this.writeByte(music >> 8);
			this.writeByte(169);
			this.writeByte(0);
			this.writeByte(32);
			this.writeWord(player);
			if (info.getSongs() != 1) {
				this.writeByte(104);
				this.writeByte(168);
				this.writeByte(190);
				this.writeWord(startAddr);
			}
			else {
				this.writeByte(162);
				this.writeByte(0);
			}
			this.writeByte(169);
			this.writeByte(2);
			this.writeBytes(playerRoutine, 6, playerLastByte - player + 7);
			break;
		case ASAPModuleType.RMT:
			this.writeExecutableHeader(initAndPlayer, info, 66, 3200, 1539);
			this.writeBytes(module, 0, ASAPInfo.getWord(module, 4) - music + 7);
			this.writeWord(3200);
			if (info.getSongs() != 1) {
				this.writeWord(3210 + info.getSongs());
				this.writeByte(168);
				this.writeByte(185);
				this.writeWord(3211);
			}
			else {
				this.writeWord(3208);
				this.writeByte(169);
				this.writeByte(0);
			}
			this.writeByte(162);
			this.writeByte(music & 255);
			this.writeByte(160);
			this.writeByte(music >> 8);
			this.writeByte(76);
			this.writeWord(1536);
			if (info.getSongs() != 1)
				this.writeBytes(info.songPos, 0, info.getSongs());
			this.writeBytes(playerRoutine, 2, playerLastByte - player + 7);
			break;
		case ASAPModuleType.TMC:
			int player2 = player + CI_CONST_ARRAY_1[(module[37] & 0xff) - 1];
			startAddr = player2 + CI_CONST_ARRAY_2[(module[37] & 0xff) - 1];
			if (info.getSongs() != 1)
				startAddr -= 3;
			this.writeExecutableHeader(initAndPlayer, info, 66, startAddr, player2);
			this.writeBytes(module, 0, moduleLen);
			this.writeWord(startAddr);
			this.writeWord(playerLastByte);
			if (info.getSongs() != 1)
				this.writeByte(72);
			this.writeByte(160);
			this.writeByte(music & 255);
			this.writeByte(162);
			this.writeByte(music >> 8);
			this.writeByte(169);
			this.writeByte(112);
			this.writeByte(32);
			this.writeWord(player);
			if (info.getSongs() != 1)
				this.writePlaTaxLda0();
			else {
				this.writeByte(169);
				this.writeByte(96);
			}
			switch (module[37]) {
			case 2:
				this.writeByte(6);
				this.writeByte(0);
				this.writeByte(76);
				this.writeWord(player);
				this.writeByte(165);
				this.writeByte(0);
				this.writeByte(230);
				this.writeByte(0);
				this.writeByte(74);
				this.writeByte(144);
				this.writeByte(5);
				this.writeByte(176);
				this.writeByte(6);
				break;
			case 3:
			case 4:
				this.writeByte(160);
				this.writeByte(1);
				this.writeByte(132);
				this.writeByte(0);
				this.writeByte(208);
				this.writeByte(10);
				this.writeByte(198);
				this.writeByte(0);
				this.writeByte(208);
				this.writeByte(12);
				this.writeByte(160);
				this.writeByte(module[37] & 0xff);
				this.writeByte(132);
				this.writeByte(0);
				this.writeByte(208);
				this.writeByte(3);
				break;
			}
			this.writeBytes(playerRoutine, 6, playerLastByte - player + 7);
			break;
		case ASAPModuleType.TM2:
			this.writeExecutableHeader(initAndPlayer, info, 66, 4992, 2051);
			this.writeBytes(module, 0, moduleLen);
			this.writeWord(4992);
			if (info.getSongs() != 1) {
				this.writeWord(5008);
				this.writeByte(72);
			}
			else
				this.writeWord(5006);
			this.writeByte(160);
			this.writeByte(music & 255);
			this.writeByte(162);
			this.writeByte(music >> 8);
			this.writeByte(169);
			this.writeByte(112);
			this.writeByte(32);
			this.writeWord(2048);
			if (info.getSongs() != 1)
				this.writePlaTaxLda0();
			else {
				this.writeByte(169);
				this.writeByte(0);
				this.writeByte(170);
			}
			this.writeByte(76);
			this.writeWord(2048);
			this.writeBytes(playerRoutine, 2, playerLastByte - player + 7);
			break;
		case ASAPModuleType.FC:
			this.writeExecutableHeader(initAndPlayer, info, 66, player, player + 3);
			this.writeWord(65535);
			this.writeWord(music);
			this.writeWord(music + moduleLen - 1);
			this.writeBytes(module, 0, moduleLen);
			this.writeBytes(playerRoutine, 2, playerLastByte - player + 7);
			break;
		}
	}

	private void writeExecutableFromSap(int[] initAndPlayer, ASAPInfo info, int type, byte[] module, int moduleLen) throws Exception
	{
		this.writeExecutableHeader(initAndPlayer, info, type, info.getInitAddress(), info.player);
		this.writeBytes(module, info.headerLen, moduleLen);
	}

	private void writeExecutableHeader(int[] initAndPlayer, ASAPInfo info, int type, int init, int player) throws Exception
	{
		if (initAndPlayer == null)
			this.writeSapHeader(info, type, init, player);
		else {
			initAndPlayer[0] = init;
			initAndPlayer[1] = player;
		}
	}

	private int writeExecutableHeaderForSongPos(int[] initAndPlayer, ASAPInfo info, int player, int codeForOneSong, int codeForManySongs, int playerOffset) throws Exception
	{
		if (info.getSongs() != 1) {
			this.writeExecutableHeader(initAndPlayer, info, 66, player - codeForManySongs, player + playerOffset);
			return player - codeForManySongs - info.getSongs();
		}
		this.writeExecutableHeader(initAndPlayer, info, 66, player - codeForOneSong, player + playerOffset);
		return player - codeForOneSong;
	}

	private void writeHexSapTag(String tag, int value) throws Exception
	{
		if (value < 0)
			return;
		this.writeString(tag);
		for (int i = 12; i >= 0; i -= 4) {
			int digit = value >> i & 15;
			this.writeByte(digit + (digit < 10 ? 48 : 55));
		}
		this.writeByte(13);
		this.writeByte(10);
	}

	private void writeNative(ASAPInfo info, byte[] module, int moduleLen) throws Exception
	{
		ASAPNativeModuleWriter nativeWriter = new ASAPNativeModuleWriter();
		nativeWriter.writer = this;
		nativeWriter.sourceModule = module;
		int type = info.type;
		switch (type) {
		case ASAPModuleType.SAP_B:
		case ASAPModuleType.SAP_C:
			int offset = info.getRmtSapOffset(module, moduleLen);
			if (offset > 0) {
				nativeWriter.sourceOffset = offset - 2;
				nativeWriter.write(info, ASAPModuleType.RMT, moduleLen - offset + 2);
				return;
			}
			nativeWriter.sourceOffset = info.headerLen;
			int blockLen = nativeWriter.getWord(4) - nativeWriter.getWord(2) + 7;
			if (blockLen < 7 || info.headerLen + blockLen >= moduleLen)
				throw new Exception("Cannot extract module from SAP");
			type = info.getOriginalModuleType(module, moduleLen);
			if (type == ASAPModuleType.FC)
				this.writeBytes(module, info.headerLen + 6, info.headerLen + blockLen);
			else
				nativeWriter.write(info, type, blockLen);
			break;
		case ASAPModuleType.FC:
			this.writeBytes(module, 0, moduleLen);
			return;
		default:
			nativeWriter.sourceOffset = 0;
			nativeWriter.write(info, type, moduleLen);
			break;
		}
	}

	private void writePlaTaxLda0() throws Exception
	{
		this.writeByte(104);
		this.writeByte(170);
		this.writeByte(169);
		this.writeByte(0);
	}

	private void writeSapHeader(ASAPInfo info, int type, int init, int player) throws Exception
	{
		this.writeString("SAP\r\n");
		this.writeTextSapTag("AUTHOR ", info.getAuthor());
		this.writeTextSapTag("NAME ", info.getTitle());
		this.writeTextSapTag("DATE ", info.getDate());
		if (info.getSongs() > 1) {
			this.writeDecSapTag("SONGS ", info.getSongs());
			if (info.getDefaultSong() > 0)
				this.writeDecSapTag("DEFSONG ", info.getDefaultSong());
		}
		if (info.getChannels() > 1)
			this.writeString("STEREO\r\n");
		if (info.isNtsc())
			this.writeString("NTSC\r\n");
		this.writeString("TYPE ");
		this.writeByte(type);
		this.writeByte(13);
		this.writeByte(10);
		if (info.getPlayerRateScanlines() != 312 || info.isNtsc())
			this.writeDecSapTag("FASTPLAY ", info.getPlayerRateScanlines());
		if (type == 67)
			this.writeHexSapTag("MUSIC ", info.getMusicAddress());
		this.writeHexSapTag("INIT ", init);
		this.writeHexSapTag("PLAYER ", player);
		this.writeHexSapTag("COVOX ", info.getCovoxAddress());
		for (int song = 0; song < info.getSongs(); song++) {
			if (info.getDuration(song) < 0)
				break;
			this.writeString("TIME ");
			byte[] s = new byte[9];
			this.writeBytes(s, 0, ASAPWriter.durationToString(s, info.getDuration(song)));
			if (info.getLoop(song))
				this.writeString(" LOOP");
			this.writeByte(13);
			this.writeByte(10);
		}
	}

	private void writeString(String s) throws Exception
	{
		int n = s.length();
		for (int i = 0; i < n; i++)
			this.writeByte(s.charAt(i));
	}

	private void writeTextSapTag(String tag, String value) throws Exception
	{
		this.writeString(tag);
		this.writeByte(34);
		if (value.length() == 0)
			value = "<?>";
		this.writeString(value);
		this.writeByte(34);
		this.writeByte(13);
		this.writeByte(10);
	}

	final void writeWord(int value) throws Exception
	{
		this.writeByte(value & 255);
		this.writeByte(value >> 8);
	}

	private void writeXexInfo(ASAPInfo info) throws Exception
	{
		byte[] title = new byte[256];
		int titleLen = ASAPWriter.formatXexInfoText(title, 0, 0, info.getTitle().length() == 0 ? "(untitled)" : info.getTitle(), false);
		byte[] author = new byte[256];
		int authorLen;
		if (info.getAuthor().length() > 0) {
			author[0] = 98;
			author[1] = 121;
			author[2] = 32;
			authorLen = ASAPWriter.formatXexInfoText(author, 3, 0, info.getAuthor(), true);
		}
		else
			authorLen = 0;
		byte[] other = new byte[256];
		int otherLen = ASAPWriter.formatXexInfoText(other, 0, 19, info.getDate(), false);
		otherLen = ASAPWriter.formatXexInfoText(other, otherLen, 27, info.getChannels() > 1 ? " STEREO" : "   MONO", false);
		int duration = info.getDuration(info.getDefaultSong());
		if (duration > 0 && ASAPWriter.secondsToString(other, otherLen, duration + 999))
			otherLen += 5;
		else
			otherLen = ASAPWriter.padXexInfo(other, otherLen, 0);
		int totalCharacters = titleLen + authorLen + otherLen;
		int totalLines = totalCharacters / 32;
		int otherAddress = 64592 - otherLen;
		int titleAddress = otherAddress - authorLen - 8 - titleLen;
		this.writeWord(titleAddress);
		this.writeBytes(getBinaryResource("xexinfo.obx", 178), 4, 6);
		this.writeBytes(title, 0, titleLen);
		for (int i = 0; i < 8; i++)
			this.writeByte(85);
		this.writeBytes(author, 0, authorLen);
		this.writeBytes(other, 0, otherLen);
		for (int i = totalLines; i < 26; i++)
			this.writeByte(112);
		this.writeByte(48);
		this.writeXexInfoTextDl(titleAddress, titleLen, titleLen - 32);
		this.writeByte(8);
		this.writeByte(0);
		for (int i = 0; i < authorLen; i += 32)
			this.writeByte(2);
		this.writeByte(16);
		for (int i = 0; i < otherLen; i += 32)
			this.writeByte(2);
		this.writeBytes(getBinaryResource("xexinfo.obx", 178), 6, 178);
	}

	private void writeXexInfoTextDl(int address, int len, int verticalScrollAt) throws Exception
	{
		this.writeByte(verticalScrollAt == 0 ? 98 : 66);
		this.writeWord(address);
		for (int i = 32; i < len; i += 32)
			this.writeByte(i == verticalScrollAt ? 34 : 2);
	}

	private static byte[] getBinaryResource(String name, int length)
	{
		java.io.DataInputStream dis = new java.io.DataInputStream(ASAPWriter.class.getResourceAsStream(name));
		byte[] result = new byte[length];
		try {
			try {
				dis.readFully(result);
			}
			finally {
				dis.close();
			}
		}
		catch (java.io.IOException e) {
			throw new RuntimeException();
		}
		return result;
	}
	private static final int[] CI_CONST_ARRAY_1 = { 3, -9, -10, -10 };
	private static final int[] CI_CONST_ARRAY_2 = { -14, -16, -17, -17 };
}
