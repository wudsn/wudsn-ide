// Generated automatically with "cito". Do not edit.
package net.sf.asap;

class FlashPack
{

	final void compress(ASAPWriter w) throws Exception
	{
		for (int i = 0; i < 65536; i++)
			this.memory[i] = -1;
		for (int i = 0; i + 5 <= w.outputOffset;) {
			int startAddress = (w.output[i] & 0xff) + ((w.output[i + 1] & 0xff) << 8);
			if (startAddress == 65535) {
				i += 2;
				startAddress = (w.output[i] & 0xff) + ((w.output[i + 1] & 0xff) << 8);
			}
			int endAddress = (w.output[i + 2] & 0xff) + ((w.output[i + 3] & 0xff) << 8);
			if (startAddress > endAddress)
				throw new Exception("Start address greater than end address");
			i += 4;
			if (i + endAddress - startAddress >= w.outputOffset)
				throw new Exception("Truncated block");
			while (startAddress <= endAddress)
				this.memory[startAddress++] = w.output[i++] & 0xff;
		}
		if (this.memory[736] < 0 || this.memory[737] < 0)
			throw new Exception("Missing run address");
		if (this.memory[252] >= 0 || this.memory[253] >= 0 || this.memory[254] >= 0 || this.memory[255] >= 0)
			throw new Exception("Conflict with decompressor variables");
		int runAddress = this.memory[736] + (this.memory[737] << 8);
		this.memory[736] = this.memory[737] = -1;
		int depackerEndAddress = this.findHole();
		this.compressedLength = 0;
		this.itemsCount = 0;
		this.putPoke(54286, 0);
		this.putPoke(53774, 0);
		this.putPoke(54272, 0);
		this.putPoke(54017, 254);
		this.putPoke(580, 255);
		this.compressMemoryArea(depackerEndAddress, 65535);
		this.compressMemoryArea(0, depackerEndAddress);
		this.putItem(FlashPackItemType.END_OF_STREAM, 0);
		this.putItems();
		int depackerStartAddress = depackerEndAddress - 87;
		int compressedStartAddress = depackerStartAddress - this.compressedLength;
		if (compressedStartAddress < 8192)
			throw new Exception("Too much compressed data");
		w.outputOffset = 0;
		w.writeWord(65535);
		w.writeWord(54017);
		w.writeWord(54017);
		w.writeByte(255);
		w.writeWord(compressedStartAddress);
		w.writeWord(depackerEndAddress);
		w.writeBytes(this.compressed, 0, this.compressedLength);
		w.writeByte(173);
		w.writeWord(compressedStartAddress);
		w.writeByte(238);
		w.writeWord(depackerStartAddress + 1);
		w.writeByte(208);
		w.writeByte(3);
		w.writeByte(238);
		w.writeWord(depackerStartAddress + 2);
		w.writeByte(96);
		w.writeByte(76);
		w.writeWord(runAddress);
		w.writeByte(133);
		w.writeByte(254);
		w.writeByte(138);
		w.writeByte(42);
		w.writeByte(170);
		w.writeByte(240);
		w.writeByte(246);
		w.writeByte(177);
		w.writeByte(254);
		w.writeByte(153);
		w.writeByte(128);
		w.writeByte(128);
		w.writeByte(200);
		w.writeByte(208);
		w.writeByte(9);
		w.writeByte(152);
		w.writeByte(56);
		w.writeByte(101);
		w.writeByte(255);
		w.writeByte(133);
		w.writeByte(255);
		w.writeByte(141);
		w.writeWord(depackerStartAddress + 26);
		w.writeByte(202);
		w.writeByte(208);
		w.writeByte(236);
		w.writeByte(6);
		w.writeByte(253);
		w.writeByte(208);
		w.writeByte(21);
		w.writeByte(6);
		w.writeByte(252);
		w.writeByte(208);
		w.writeByte(7);
		w.writeByte(56);
		w.writeByte(32);
		w.writeWord(depackerStartAddress);
		w.writeByte(42);
		w.writeByte(133);
		w.writeByte(252);
		w.writeByte(169);
		w.writeByte(1);
		w.writeByte(144);
		w.writeByte(4);
		w.writeByte(32);
		w.writeWord(depackerStartAddress);
		w.writeByte(42);
		w.writeByte(133);
		w.writeByte(253);
		w.writeByte(32);
		w.writeWord(depackerStartAddress);
		w.writeByte(162);
		w.writeByte(1);
		w.writeByte(144);
		w.writeByte(206);
		w.writeByte(74);
		w.writeByte(208);
		w.writeByte(194);
		w.writeByte(32);
		w.writeWord(depackerStartAddress);
		w.writeByte(176);
		w.writeByte(193);
		w.writeByte(168);
		w.writeByte(32);
		w.writeWord(depackerStartAddress);
		w.writeByte(144);
		w.writeByte(202);
		w.writeWord(736);
		w.writeWord(737);
		w.writeWord(depackerStartAddress + 50);
	}

	private void compressMemoryArea(int startAddress, int endAddress)
	{
		int lastDistance = -1;
		for (int address = startAddress; address <= endAddress;) {
			while (this.memory[address] < 0)
				if (++address > endAddress)
					return;
			this.putItem(FlashPackItemType.SET_ADDRESS, address);
			while (address <= endAddress && this.memory[address] >= 0) {
				int bestMatch = 0;
				int bestDistance = -1;
				for (int backAddress = address - 1; backAddress >= startAddress && address - backAddress < 128; backAddress--) {
					int match;
					for (match = 0; address + match <= endAddress; match++) {
						int data = this.memory[address + match];
						if (data < 0 || data != this.memory[backAddress + match])
							break;
					}
					if (bestMatch < match) {
						bestMatch = match;
						bestDistance = address - backAddress;
					}
					else if (bestMatch == match && address - backAddress == lastDistance)
						bestDistance = lastDistance;
				}
				switch (bestMatch) {
				case 0:
				case 1:
					this.putItem(FlashPackItemType.LITERAL, this.memory[address++]);
					continue;
				case 2:
					this.putItem(FlashPackItemType.COPY_TWO_BYTES, bestDistance);
					break;
				case 3:
					this.putItem(FlashPackItemType.COPY_THREE_BYTES, bestDistance);
					break;
				case 4:
					if (bestDistance == lastDistance)
						this.putItem(FlashPackItemType.COPY_MANY_BYTES, 4);
					else if (this.isLiteralPreferred()) {
						this.putItem(FlashPackItemType.LITERAL, this.memory[address]);
						this.putItem(FlashPackItemType.COPY_THREE_BYTES, bestDistance);
					}
					else {
						this.putItem(FlashPackItemType.COPY_THREE_BYTES, bestDistance);
						this.putItem(FlashPackItemType.LITERAL, this.memory[address + 3]);
					}
					break;
				case 5:
					if (bestDistance == lastDistance)
						this.putItem(FlashPackItemType.COPY_MANY_BYTES, 5);
					else {
						this.putItem(FlashPackItemType.COPY_THREE_BYTES, bestDistance);
						this.putItem(FlashPackItemType.COPY_TWO_BYTES, bestDistance);
					}
					break;
				case 6:
					if (bestDistance == lastDistance)
						this.putItem(FlashPackItemType.COPY_MANY_BYTES, 6);
					else {
						this.putItem(FlashPackItemType.COPY_THREE_BYTES, bestDistance);
						this.putItem(FlashPackItemType.COPY_THREE_BYTES, bestDistance);
					}
					break;
				default:
					int length = bestMatch;
					if (bestDistance != lastDistance) {
						if (this.isLiteralPreferred() && length % 255 == 4) {
							this.putItem(FlashPackItemType.LITERAL, this.memory[address]);
							length--;
						}
						this.putItem(FlashPackItemType.COPY_THREE_BYTES, bestDistance);
						length -= 3;
					}
					else if (this.isLiteralPreferred() && length % 255 == 1) {
						this.putItem(FlashPackItemType.LITERAL, this.memory[address]);
						length--;
					}
					for (; length > 255; length -= 255)
						this.putItem(FlashPackItemType.COPY_MANY_BYTES, 255);
					switch (length) {
					case 0:
						break;
					case 1:
						this.putItem(FlashPackItemType.LITERAL, this.memory[address + bestMatch - 1]);
						break;
					case 2:
						this.putItem(FlashPackItemType.COPY_TWO_BYTES, bestDistance);
						break;
					case 3:
						this.putItem(FlashPackItemType.COPY_THREE_BYTES, bestDistance);
						break;
					default:
						this.putItem(FlashPackItemType.COPY_MANY_BYTES, length);
						break;
					}
					break;
				}
				address += bestMatch;
				lastDistance = bestDistance;
			}
		}
	}
	private final byte[] compressed = new byte[65536];
	private int compressedLength;

	private int findHole() throws Exception
	{
		int end = 48159;
		for (;;) {
			while (this.memory[end] >= 0)
				if (--end < 9216)
					throw new Exception("Too much data to compress");
			int start = end;
			while (this.memory[--start] < 0)
				if (end - start >= 1023)
					return end;
			end = start;
		}
	}

	private int getInnerFlags(int index)
	{
		int flags = 1;
		do {
			flags <<= 1;
			if (index < this.itemsCount && this.items[index++].type != FlashPackItemType.LITERAL)
				flags++;
		}
		while (flags < 256);
		return flags & 255;
	}

	private boolean isLiteralPreferred()
	{
		return (this.itemsCount & 7) == 7 && this.getInnerFlags(this.itemsCount - 7) == 0;
	}
	private final FlashPackItem[] items = new FlashPackItem[] { new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem(), new FlashPackItem() };
	private int itemsCount;
	private final int[] memory = new int[65536];

	private void putItem(int type, int value)
	{
		if (this.itemsCount >= 64) {
			this.putItems();
			this.itemsCount = 0;
		}
		this.items[this.itemsCount].type = type;
		this.items[this.itemsCount].value = value;
		this.itemsCount++;
	}

	private void putItems()
	{
		int outerFlags = 0;
		for (int i = 0; i < this.itemsCount; i += 8) {
			if (this.getInnerFlags(i) != 0)
				outerFlags |= 128 >> (i >> 3);
		}
		this.compressed[this.compressedLength++] = (byte) outerFlags;
		for (int i = 0; i < this.itemsCount; i++) {
			if ((i & 7) == 0) {
				int flags = this.getInnerFlags(i);
				if (flags != 0)
					this.compressed[this.compressedLength++] = (byte) flags;
			}
			this.compressedLength += this.items[i].writeValueTo(this.compressed, this.compressedLength);
		}
	}

	private void putPoke(int address, int value)
	{
		this.putItem(FlashPackItemType.SET_ADDRESS, address);
		this.putItem(FlashPackItemType.LITERAL, value);
	}
}
