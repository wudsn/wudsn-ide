// Generated automatically with "cito". Do not edit.
package net.sf.asap;

class ASAPNativeModuleWriter
{
	private int addressDiff;

	private void copy(int endOffset) throws Exception
	{
		this.writer.writeBytes(this.sourceModule, this.sourceOffset + this.writer.outputOffset, this.sourceOffset + endOffset);
	}

	private int getByte(int offset)
	{
		return this.sourceModule[this.sourceOffset + offset] & 0xff;
	}

	final int getWord(int offset)
	{
		return ASAPInfo.getWord(this.sourceModule, this.sourceOffset + offset);
	}

	private void relocateBytes(int lowOffset, int highOffset, int count, int shift) throws Exception
	{
		lowOffset += this.sourceOffset;
		highOffset += this.sourceOffset;
		for (int i = 0; i < count; i++) {
			int address = (this.sourceModule[lowOffset + i] & 0xff) + ((this.sourceModule[highOffset + i] & 0xff) << 8);
			if (address != 0 && address != 65535)
				address += this.addressDiff;
			this.writer.writeByte(address >> shift & 255);
		}
	}

	private void relocateLowHigh(int count) throws Exception
	{
		int lowOffset = this.writer.outputOffset;
		this.relocateBytes(lowOffset, lowOffset + count, count, 0);
		this.relocateBytes(lowOffset, lowOffset + count, count, 8);
	}

	private void relocateWords(int count) throws Exception
	{
		while (--count >= 0) {
			int address = this.getWord(this.writer.outputOffset);
			if (address != 0 && address != 65535)
				address += this.addressDiff;
			this.writer.writeWord(address);
		}
	}
	byte[] sourceModule;
	int sourceOffset;

	final void write(ASAPInfo info, int type, int moduleLen) throws Exception
	{
		int startAddr = this.getWord(2);
		this.addressDiff = info.getMusicAddress() < 0 ? 0 : info.getMusicAddress() - startAddr;
		if (this.getWord(4) + this.addressDiff > 65535)
			throw new Exception("Address set too high");
		switch (type) {
		case ASAPModuleType.CMC:
		case ASAPModuleType.CM3:
		case ASAPModuleType.CMR:
		case ASAPModuleType.CMS:
			this.relocateWords(3);
			this.copy(26);
			this.relocateLowHigh(64);
			break;
		case ASAPModuleType.DLT:
			this.relocateWords(3);
			break;
		case ASAPModuleType.MPT:
			this.relocateWords(99);
			this.copy(454);
			this.relocateLowHigh(4);
			break;
		case ASAPModuleType.RMT:
			this.writer.writeWord(65535);
			this.relocateWords(2);
			this.copy(14);
			int patternLowAddress = this.getWord(16);
			this.relocateWords(patternLowAddress - startAddr - 8 >> 1);
			this.relocateLowHigh(this.getWord(18) - patternLowAddress);
			int songOffset = 6 + this.getWord(20) - startAddr;
			this.copy(songOffset);
			int songEnd = 7 + this.getWord(4) - startAddr;
			while (songOffset + 3 < songEnd) {
				int nextSongOffset = songOffset + this.getByte(9) - 48;
				if (this.getByte(songOffset) == 254) {
					this.copy(songOffset + 2);
					this.relocateWords(1);
				}
				if (nextSongOffset > songEnd)
					nextSongOffset = songEnd;
				this.copy(nextSongOffset);
				songOffset = nextSongOffset;
			}
			this.copy(songEnd);
			if (moduleLen >= songEnd + 5)
				this.relocateWords(2);
			break;
		case ASAPModuleType.TMC:
			this.relocateWords(3);
			this.copy(38);
			this.relocateLowHigh(64);
			this.relocateLowHigh(128);
			break;
		case ASAPModuleType.TM2:
			this.relocateWords(3);
			this.copy(134);
			this.relocateBytes(134, 774, 128, 0);
			this.relocateLowHigh(256);
			this.relocateBytes(134, 774, 128, 8);
			break;
		default:
			throw new Exception("Impossible conversion");
		}
		this.copy(moduleLen);
	}
	ASAPWriter writer;
}
