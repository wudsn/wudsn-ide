// Generated automatically with "cito". Do not edit.
package net.sf.asap;

interface ASAPModuleType
{
	int SAP_B = 0;
	int SAP_C = 1;
	int SAP_D = 2;
	int SAP_S = 3;
	int CMC = 4;
	int CM3 = 5;
	int CMR = 6;
	int CMS = 7;
	int DLT = 8;
	int MPT = 9;
	int RMT = 10;
	int TMC = 11;
	int TM2 = 12;
	int FC = 13;
}
