// Generated automatically with "cito". Do not edit.
package net.sf.asap;

/**
 * Forward-only iterator over a directory on an ATR disk image.
 */
public class AATRDirectory
{
	AATR disk;
	private int fileNo;
	private String filename;

	/**
	 * Advances to the specified entry.
	 * Returns whether the entry is found.
	 * @param filename The name of the file or directory to find.
	 */
	public final boolean findEntry(String filename)
	{
		for (;;) {
			String currentFilename = this.nextEntry();
			if (currentFilename == null)
				return false;
			if (currentFilename.equals(filename))
				return true;
		}
	}

	/**
	 * Advances to the specified entry, which may be in a subdirectory.
	 * Returns whether the entry is found.
	 * @param path The name of the file or directory to find, with subdirectories separated with slashes.
	 */
	public final boolean findEntryRecursively(String path)
	{
		int i = 0;
		int pathLength = path.length();
		for (int j = 0; j < pathLength; j++) {
			if (path.charAt(j) == 47) {
				if (j - i > 12)
					return false;
				String dirname = path.substring(i, i + j - i);
				if (!this.findEntry(dirname) || !this.isEntryDirectory())
					return false;
				this.open(this);
				i = j + 1;
			}
		}
		if (pathLength - i > 12)
			return false;
		String filename = path.substring(i, i + pathLength - i);
		return this.findEntry(filename);
	}
	private int firstSector;

	final int getEntryFirstSector()
	{
		int sectorOffset = (this.fileNo & 7) << 4;
		return this.sector[sectorOffset + 3] & 0xff | (this.sector[sectorOffset + 4] & 0xff) << 8;
	}

	final int getEntryType()
	{
		int sectorOffset = (this.fileNo & 7) << 4;
		return this.sector[sectorOffset] & 215;
	}

	private int getFilenamePart(int sectorOffset, int maxLength)
	{
		for (int length = 0; length < maxLength; length++) {
			int c = this.sector[sectorOffset + length] & 0xff;
			if (c == 32) {
				int result = length;
				while (++length < maxLength) {
					if (this.sector[sectorOffset + length] != 32)
						return -1;
				}
				return result;
			}
			if (c >= 65 && c <= 90 || c >= 48 && c <= 57 || c == 95)
				continue;
			return -1;
		}
		return maxLength;
	}

	/**
	 * Returns <code>true</code> if the current entry is a directory.
	 */
	public final boolean isEntryDirectory()
	{
		return this.getEntryType() == 16;
	}

	/**
	 * Advances to the next entry (file or directory).
	 * Returns the filename or <code>null</code> if no more entries found.
	 */
	public final String nextEntry()
	{
		for (;;) {
			if (this.fileNo >= 63)
				return null;
			this.fileNo++;
			int sectorOffset = (this.fileNo & 7) << 4;
			if (sectorOffset == 0 && !this.disk.readSector(this.firstSector + (this.fileNo >> 3), this.sector, 128))
				return null;
			switch (this.sector[sectorOffset] & 215) {
			case 0:
				return null;
			case 64:
				if (this.disk.getBytesPerSector() != 128)
					continue;
				break;
			case 66:
			case 3:
			case 70:
			case 16:
				break;
			default:
				continue;
			}
			int filenameLength = this.getFilenamePart(sectorOffset + 5, 8);
			if (filenameLength < 0)
				continue;
			int extLength = this.getFilenamePart(sectorOffset + 13, 3);
			if (extLength < 0 || filenameLength == 0 && extLength == 0)
				continue;
			this.filename = new String(this.sector, sectorOffset + 5, filenameLength);
			if (extLength > 0) {
				this.sector[sectorOffset + 12] = 46;
				String ext = new String(this.sector, sectorOffset + 12, 1 + extLength);
				this.filename += ext;
			}
			return this.filename;
		}
	}

	/**
	 * Opens the specified subdirectory.
	 * @param directory The iterator pointing at the subdirectory to open.
	 */
	public final void open(AATRDirectory directory)
	{
		this.disk = directory.disk;
		this.firstSector = directory.getEntryFirstSector();
		this.fileNo = -1;
	}

	/**
	 * Opens the root directory of the specified disk image.
	 * @param disk The disk image.
	 */
	public final void openRoot(AATR disk)
	{
		this.disk = disk;
		this.firstSector = 361;
		this.fileNo = -1;
	}
	private final byte[] sector = new byte[128];
}
