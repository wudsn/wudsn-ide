// Generated automatically with "cito". Do not edit.
package net.sf.asap;

class DurationParser
{
	private int length;

	final int parse(String s) throws Exception
	{
		this.source = s;
		this.position = 0;
		this.length = s.length();
		int result = this.parseDigit(9);
		if (this.position < this.length) {
			int digit = s.charAt(this.position) - 48;
			if (digit >= 0 && digit <= 9) {
				this.position++;
				result = result * 10 + digit;
			}
			if (this.position < this.length && s.charAt(this.position) == 58) {
				this.position++;
				result = (result * 6 + this.parseDigit(5)) * 10;
				result += this.parseDigit(9);
			}
		}
		result *= 1000;
		if (this.position >= this.length)
			return result;
		if (s.charAt(this.position++) != 46)
			throw new Exception("Invalid duration");
		result += this.parseDigit(9) * 100;
		if (this.position >= this.length)
			return result;
		result += this.parseDigit(9) * 10;
		if (this.position >= this.length)
			return result;
		result += this.parseDigit(9);
		return result;
	}

	private int parseDigit(int max) throws Exception
	{
		if (this.position >= this.length)
			throw new Exception("Invalid duration");
		int digit = this.source.charAt(this.position++) - 48;
		if (digit < 0 || digit > max)
			throw new Exception("Invalid duration");
		return digit;
	}
	private int position;
	private String source;
}
