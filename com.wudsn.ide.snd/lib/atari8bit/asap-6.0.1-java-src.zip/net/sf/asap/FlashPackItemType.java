// Generated automatically with "fut". Do not edit.
package net.sf.asap;

enum FlashPackItemType
{
	LITERAL,
	COPY_TWO_BYTES,
	COPY_THREE_BYTES,
	COPY_MANY_BYTES,
	SET_ADDRESS,
	END_OF_STREAM
}
