// Generated automatically with "cito". Do not edit.
package net.sf.asap;

interface NmiStatus
{
	int RESET = 0;
	int ON_V_BLANK = 1;
	int WAS_V_BLANK = 2;
}
