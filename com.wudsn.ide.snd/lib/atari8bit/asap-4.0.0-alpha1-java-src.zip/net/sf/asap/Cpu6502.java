// Generated automatically with "cito". Do not edit.
package net.sf.asap;

class Cpu6502
{
	int a;
	int c;

	/**
	 * Runs 6502 emulation for the specified number of Atari scanlines.
	 * Each scanline is 114 cycles of which 9 is taken by ANTIC for memory refresh.
	 */
	final void doFrame(ASAP asap, int cycleLimit)
	{
		int pc = this.pc;
		int nz = this.nz;
		int a = this.a;
		int x = this.x;
		int y = this.y;
		int c = this.c;
		int s = this.s;
		int vdi = this.vdi;
		while (asap.cycle < cycleLimit) {
			if (asap.cycle >= asap.nextEventCycle) {
				this.pc = pc;
				this.s = s;
				asap.handleEvent();
				pc = this.pc;
				s = this.s;
				if ((vdi & 4) == 0 && asap.pokeys.basePokey.irqst != 255) {
					asap.memory[256 + s] = (byte) (pc >> 8);
					s = s - 1 & 255;
					asap.memory[256 + s] = (byte) pc;
					s = s - 1 & 255;
					asap.memory[256 + s] = (byte) (((nz | nz >> 1) & 128) + vdi + ((nz & 255) == 0 ? 2 : 0) + c + 32);
					s = s - 1 & 255;
					vdi |= 4;
					pc = (asap.memory[65534] & 0xff) + ((asap.memory[65535] & 0xff) << 8);
					asap.cycle += 7;
				}
			}
			int data = asap.memory[pc++] & 0xff;
			asap.cycle += CI_CONST_ARRAY_1[data];
			int addr = 0;
			switch (data) {
			case 0:
				pc++;
				asap.memory[256 + s] = (byte) (pc >> 8);
				s = s - 1 & 255;
				asap.memory[256 + s] = (byte) pc;
				s = s - 1 & 255;
				asap.memory[256 + s] = (byte) (((nz | nz >> 1) & 128) + vdi + ((nz & 255) == 0 ? 2 : 0) + c + 48);
				s = s - 1 & 255;
				vdi |= 4;
				pc = (asap.memory[65534] & 0xff) + ((asap.memory[65535] & 0xff) << 8);
				continue;
			case 1:
			case 3:
			case 33:
			case 35:
			case 65:
			case 67:
			case 97:
			case 99:
			case 129:
			case 131:
			case 161:
			case 163:
			case 193:
			case 195:
			case 225:
			case 227:
				addr = (asap.memory[pc++] & 0xff) + x & 255;
				addr = (asap.memory[addr] & 0xff) + ((asap.memory[addr + 1 & 255] & 0xff) << 8);
				break;
			case 2:
			case 18:
			case 34:
			case 50:
			case 66:
			case 82:
			case 98:
			case 114:
			case 146:
			case 178:
			case 210:
			case 242:
				pc--;
				asap.cycle = asap.nextEventCycle;
				continue;
			case 4:
			case 68:
			case 100:
			case 20:
			case 52:
			case 84:
			case 116:
			case 212:
			case 244:
			case 128:
			case 130:
			case 137:
			case 194:
			case 226:
				pc++;
				continue;
			case 5:
			case 6:
			case 7:
			case 36:
			case 37:
			case 38:
			case 39:
			case 69:
			case 70:
			case 71:
			case 101:
			case 102:
			case 103:
			case 132:
			case 133:
			case 134:
			case 135:
			case 164:
			case 165:
			case 166:
			case 167:
			case 196:
			case 197:
			case 198:
			case 199:
			case 228:
			case 229:
			case 230:
			case 231:
				addr = asap.memory[pc++] & 0xff;
				break;
			case 8:
				asap.memory[256 + s] = (byte) (((nz | nz >> 1) & 128) + vdi + ((nz & 255) == 0 ? 2 : 0) + c + 48);
				s = s - 1 & 255;
				continue;
			case 9:
			case 41:
			case 73:
			case 105:
			case 160:
			case 162:
			case 169:
			case 192:
			case 201:
			case 224:
			case 233:
			case 235:
				addr = pc++;
				break;
			case 10:
				c = a >> 7;
				nz = a = a << 1 & 255;
				continue;
			case 11:
			case 43:
				nz = a &= asap.memory[pc++] & 0xff;
				c = nz >> 7;
				continue;
			case 12:
				pc += 2;
				continue;
			case 13:
			case 14:
			case 15:
			case 44:
			case 45:
			case 46:
			case 47:
			case 77:
			case 78:
			case 79:
			case 108:
			case 109:
			case 110:
			case 111:
			case 140:
			case 141:
			case 142:
			case 143:
			case 172:
			case 173:
			case 174:
			case 175:
			case 204:
			case 205:
			case 206:
			case 207:
			case 236:
			case 237:
			case 238:
			case 239:
				addr = asap.memory[pc++] & 0xff;
				addr += (asap.memory[pc++] & 0xff) << 8;
				break;
			case 16:
				if (nz < 128)
					break;
				pc++;
				continue;
			case 17:
			case 49:
			case 81:
			case 113:
			case 177:
			case 179:
			case 209:
			case 241:
				addr = asap.memory[pc++] & 0xff;
				addr = (asap.memory[addr] & 0xff) + ((asap.memory[addr + 1 & 255] & 0xff) << 8) + y & 65535;
				if ((addr & 255) < y)
					asap.cycle++;
				break;
			case 19:
			case 51:
			case 83:
			case 115:
			case 145:
			case 211:
			case 243:
				addr = asap.memory[pc++] & 0xff;
				addr = (asap.memory[addr] & 0xff) + ((asap.memory[addr + 1 & 255] & 0xff) << 8) + y & 65535;
				break;
			case 21:
			case 22:
			case 23:
			case 53:
			case 54:
			case 55:
			case 85:
			case 86:
			case 87:
			case 117:
			case 118:
			case 119:
			case 148:
			case 149:
			case 180:
			case 181:
			case 213:
			case 214:
			case 215:
			case 245:
			case 246:
			case 247:
				addr = (asap.memory[pc++] & 0xff) + x & 255;
				break;
			case 24:
				c = 0;
				continue;
			case 25:
			case 57:
			case 89:
			case 121:
			case 185:
			case 187:
			case 190:
			case 191:
			case 217:
			case 249:
				addr = asap.memory[pc++] & 0xff;
				addr = addr + ((asap.memory[pc++] & 0xff) << 8) + y & 65535;
				if ((addr & 255) < y)
					asap.cycle++;
				break;
			case 27:
			case 59:
			case 91:
			case 123:
			case 153:
			case 219:
			case 251:
				addr = asap.memory[pc++] & 0xff;
				addr = addr + ((asap.memory[pc++] & 0xff) << 8) + y & 65535;
				break;
			case 28:
			case 60:
			case 92:
			case 124:
			case 220:
			case 252:
				if ((asap.memory[pc++] & 0xff) + x >= 256)
					asap.cycle++;
				pc++;
				continue;
			case 29:
			case 61:
			case 93:
			case 125:
			case 188:
			case 189:
			case 221:
			case 253:
				addr = asap.memory[pc++] & 0xff;
				addr = addr + ((asap.memory[pc++] & 0xff) << 8) + x & 65535;
				if ((addr & 255) < x)
					asap.cycle++;
				break;
			case 30:
			case 31:
			case 62:
			case 63:
			case 94:
			case 95:
			case 126:
			case 127:
			case 157:
			case 222:
			case 223:
			case 254:
			case 255:
				addr = asap.memory[pc++] & 0xff;
				addr = addr + ((asap.memory[pc++] & 0xff) << 8) + x & 65535;
				break;
			case 32:
				addr = asap.memory[pc++] & 0xff;
				asap.memory[256 + s] = (byte) (pc >> 8);
				s = s - 1 & 255;
				asap.memory[256 + s] = (byte) pc;
				s = s - 1 & 255;
				pc = addr + ((asap.memory[pc] & 0xff) << 8);
				continue;
			case 40:
				s = s + 1 & 255;
				vdi = asap.memory[256 + s] & 0xff;
				nz = ((vdi & 128) << 1) + (~vdi & 2);
				c = vdi & 1;
				vdi &= 76;
				if ((vdi & 4) == 0 && asap.pokeys.basePokey.irqst != 255) {
					asap.memory[256 + s] = (byte) (pc >> 8);
					s = s - 1 & 255;
					asap.memory[256 + s] = (byte) pc;
					s = s - 1 & 255;
					asap.memory[256 + s] = (byte) (((nz | nz >> 1) & 128) + vdi + ((nz & 255) == 0 ? 2 : 0) + c + 32);
					s = s - 1 & 255;
					vdi |= 4;
					pc = (asap.memory[65534] & 0xff) + ((asap.memory[65535] & 0xff) << 8);
					asap.cycle += 7;
				}
				continue;
			case 42:
				a = (a << 1) + c;
				c = a >> 8;
				nz = a &= 255;
				continue;
			case 48:
				if (nz >= 128)
					break;
				pc++;
				continue;
			case 56:
				c = 1;
				continue;
			case 64:
				s = s + 1 & 255;
				vdi = asap.memory[256 + s] & 0xff;
				nz = ((vdi & 128) << 1) + (~vdi & 2);
				c = vdi & 1;
				vdi &= 76;
				s = s + 1 & 255;
				pc = asap.memory[256 + s] & 0xff;
				s = s + 1 & 255;
				addr = asap.memory[256 + s] & 0xff;
				pc += addr << 8;
				if ((vdi & 4) == 0 && asap.pokeys.basePokey.irqst != 255) {
					asap.memory[256 + s] = (byte) (pc >> 8);
					s = s - 1 & 255;
					asap.memory[256 + s] = (byte) pc;
					s = s - 1 & 255;
					asap.memory[256 + s] = (byte) (((nz | nz >> 1) & 128) + vdi + ((nz & 255) == 0 ? 2 : 0) + c + 32);
					s = s - 1 & 255;
					vdi |= 4;
					pc = (asap.memory[65534] & 0xff) + ((asap.memory[65535] & 0xff) << 8);
					asap.cycle += 7;
				}
				continue;
			case 72:
				asap.memory[256 + s] = (byte) a;
				s = s - 1 & 255;
				continue;
			case 74:
				c = a & 1;
				nz = a >>= 1;
				continue;
			case 75:
				a &= asap.memory[pc++] & 0xff;
				c = a & 1;
				nz = a >>= 1;
				continue;
			case 76:
				addr = asap.memory[pc++] & 0xff;
				pc = addr + ((asap.memory[pc] & 0xff) << 8);
				continue;
			case 80:
				if ((vdi & 64) == 0)
					break;
				pc++;
				continue;
			case 88:
				vdi &= 72;
				if ((vdi & 4) == 0 && asap.pokeys.basePokey.irqst != 255) {
					asap.memory[256 + s] = (byte) (pc >> 8);
					s = s - 1 & 255;
					asap.memory[256 + s] = (byte) pc;
					s = s - 1 & 255;
					asap.memory[256 + s] = (byte) (((nz | nz >> 1) & 128) + vdi + ((nz & 255) == 0 ? 2 : 0) + c + 32);
					s = s - 1 & 255;
					vdi |= 4;
					pc = (asap.memory[65534] & 0xff) + ((asap.memory[65535] & 0xff) << 8);
					asap.cycle += 7;
				}
				continue;
			case 96:
				s = s + 1 & 255;
				pc = asap.memory[256 + s] & 0xff;
				s = s + 1 & 255;
				addr = asap.memory[256 + s] & 0xff;
				pc += (addr << 8) + 1;
				continue;
			case 104:
				s = s + 1 & 255;
				a = asap.memory[256 + s] & 0xff;
				nz = a;
				continue;
			case 106:
				nz = (c << 7) + (a >> 1);
				c = a & 1;
				a = nz;
				continue;
			case 107:
				data = a & asap.memory[pc++] & 0xff;
				nz = a = (data >> 1) + (c << 7);
				vdi = (vdi & 12) + ((a ^ data) & 64);
				if ((vdi & 8) == 0)
					c = data >> 7;
				else {
					if ((data & 15) >= 5)
						a = (a & 240) + (a + 6 & 15);
					if (data >= 80) {
						a = a + 96 & 255;
						c = 1;
					}
					else
						c = 0;
				}
				continue;
			case 112:
				if ((vdi & 64) != 0)
					break;
				pc++;
				continue;
			case 120:
				vdi |= 4;
				continue;
			case 136:
				nz = y = y - 1 & 255;
				continue;
			case 138:
				nz = a = x;
				continue;
			case 139:
				data = asap.memory[pc++] & 0xff;
				a &= (data | 239) & x;
				nz = a & data;
				continue;
			case 144:
				if (c == 0)
					break;
				pc++;
				continue;
			case 147:
				{
					addr = asap.memory[pc++] & 0xff;
					int hi = asap.memory[addr + 1 & 255] & 0xff;
					addr = asap.memory[addr] & 0xff;
					data = hi + 1 & a & x;
					addr += y;
					if (addr >= 256)
						hi = data - 1;
					addr += hi << 8;
					if ((addr & 63744) == 53248)
						asap.pokeHardware(addr, data);
					else
						asap.memory[addr] = (byte) data;
				}
				continue;
			case 150:
			case 151:
			case 182:
			case 183:
				addr = (asap.memory[pc++] & 0xff) + y & 255;
				break;
			case 152:
				nz = a = y;
				continue;
			case 154:
				s = x;
				continue;
			case 155:
				s = a & x;
				{
					addr = asap.memory[pc++] & 0xff;
					int hi = asap.memory[pc++] & 0xff;
					data = hi + 1 & s;
					addr += y;
					if (addr >= 256)
						hi = data - 1;
					addr += hi << 8;
					if ((addr & 63744) == 53248)
						asap.pokeHardware(addr, data);
					else
						asap.memory[addr] = (byte) data;
				}
				continue;
			case 156:
				{
					addr = asap.memory[pc++] & 0xff;
					int hi = asap.memory[pc++] & 0xff;
					data = hi + 1 & y;
					addr += x;
					if (addr >= 256)
						hi = data - 1;
					addr += hi << 8;
					if ((addr & 63744) == 53248)
						asap.pokeHardware(addr, data);
					else
						asap.memory[addr] = (byte) data;
				}
				continue;
			case 158:
				{
					addr = asap.memory[pc++] & 0xff;
					int hi = asap.memory[pc++] & 0xff;
					data = hi + 1 & x;
					addr += y;
					if (addr >= 256)
						hi = data - 1;
					addr += hi << 8;
					if ((addr & 63744) == 53248)
						asap.pokeHardware(addr, data);
					else
						asap.memory[addr] = (byte) data;
				}
				continue;
			case 159:
				{
					addr = asap.memory[pc++] & 0xff;
					int hi = asap.memory[pc++] & 0xff;
					data = hi + 1 & a & x;
					addr += y;
					if (addr >= 256)
						hi = data - 1;
					addr += hi << 8;
					if ((addr & 63744) == 53248)
						asap.pokeHardware(addr, data);
					else
						asap.memory[addr] = (byte) data;
				}
				continue;
			case 168:
				nz = y = a;
				continue;
			case 170:
				nz = x = a;
				continue;
			case 171:
				nz = x = a &= asap.memory[pc++] & 0xff;
				continue;
			case 176:
				if (c != 0)
					break;
				pc++;
				continue;
			case 184:
				vdi &= 12;
				continue;
			case 186:
				nz = x = s;
				continue;
			case 200:
				nz = y = y + 1 & 255;
				continue;
			case 202:
				nz = x = x - 1 & 255;
				continue;
			case 203:
				nz = asap.memory[pc++] & 0xff;
				x &= a;
				c = x >= nz ? 1 : 0;
				nz = x = x - nz & 255;
				continue;
			case 208:
				if ((nz & 255) != 0)
					break;
				pc++;
				continue;
			case 216:
				vdi &= 68;
				continue;
			case 232:
				nz = x = x + 1 & 255;
				continue;
			case 234:
			case 26:
			case 58:
			case 90:
			case 122:
			case 218:
			case 250:
				continue;
			case 240:
				if ((nz & 255) == 0)
					break;
				pc++;
				continue;
			case 248:
				vdi |= 8;
				continue;
			default:
				continue;
			}
			switch (data) {
			case 1:
			case 5:
			case 9:
			case 13:
			case 17:
			case 21:
			case 25:
			case 29:
				nz = a |= (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				break;
			case 3:
			case 7:
			case 15:
			case 19:
			case 23:
			case 27:
			case 31:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				c = nz >> 7;
				nz = nz << 1 & 255;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				nz = a |= nz;
				break;
			case 6:
			case 14:
			case 22:
			case 30:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				c = nz >> 7;
				nz = nz << 1 & 255;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				break;
			case 16:
			case 48:
			case 80:
			case 112:
			case 144:
			case 176:
			case 208:
			case 240:
				addr = asap.memory[pc];
				pc++;
				addr += pc;
				if ((addr ^ pc) >> 8 != 0)
					asap.cycle++;
				asap.cycle++;
				pc = addr;
				break;
			case 33:
			case 37:
			case 41:
			case 45:
			case 49:
			case 53:
			case 57:
			case 61:
				nz = a &= (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				break;
			case 35:
			case 39:
			case 47:
			case 51:
			case 55:
			case 59:
			case 63:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				nz = (nz << 1) + c;
				c = nz >> 8;
				nz &= 255;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				nz = a &= nz;
				break;
			case 36:
			case 44:
				nz = (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				vdi = (vdi & 12) + (nz & 64);
				nz = ((nz & 128) << 1) + (nz & a);
				break;
			case 38:
			case 46:
			case 54:
			case 62:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				nz = (nz << 1) + c;
				c = nz >> 8;
				nz &= 255;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				break;
			case 65:
			case 69:
			case 73:
			case 77:
			case 81:
			case 85:
			case 89:
			case 93:
				nz = a ^= (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				break;
			case 67:
			case 71:
			case 79:
			case 83:
			case 87:
			case 91:
			case 95:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				c = nz & 1;
				nz >>= 1;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				nz = a ^= nz;
				break;
			case 70:
			case 78:
			case 86:
			case 94:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				c = nz & 1;
				nz >>= 1;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				break;
			case 97:
			case 101:
			case 105:
			case 109:
			case 113:
			case 117:
			case 121:
			case 125:
				data = (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				{
					int tmp = a + data + c;
					nz = tmp & 255;
					if ((vdi & 8) == 0) {
						vdi = (vdi & 12) + ((~(data ^ a) & (a ^ tmp)) >> 1 & 64);
						c = tmp >> 8;
						a = nz;
					}
					else {
						int al = (a & 15) + (data & 15) + c;
						if (al >= 10) {
							tmp += al < 26 ? 6 : -10;
							if (nz != 0)
								nz = (tmp & 128) + 1;
						}
						vdi = (vdi & 12) + ((~(data ^ a) & (a ^ tmp)) >> 1 & 64);
						if (tmp >= 160) {
							c = 1;
							a = tmp + 96 & 255;
						}
						else {
							c = 0;
							a = tmp;
						}
					}
				}
				break;
			case 99:
			case 103:
			case 111:
			case 115:
			case 119:
			case 123:
			case 127:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				nz += c << 8;
				c = nz & 1;
				nz >>= 1;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				data = nz;
				{
					int tmp = a + data + c;
					nz = tmp & 255;
					if ((vdi & 8) == 0) {
						vdi = (vdi & 12) + ((~(data ^ a) & (a ^ tmp)) >> 1 & 64);
						c = tmp >> 8;
						a = nz;
					}
					else {
						int al = (a & 15) + (data & 15) + c;
						if (al >= 10) {
							tmp += al < 26 ? 6 : -10;
							if (nz != 0)
								nz = (tmp & 128) + 1;
						}
						vdi = (vdi & 12) + ((~(data ^ a) & (a ^ tmp)) >> 1 & 64);
						if (tmp >= 160) {
							c = 1;
							a = tmp + 96 & 255;
						}
						else {
							c = 0;
							a = tmp;
						}
					}
				}
				break;
			case 102:
			case 110:
			case 118:
			case 126:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				nz += c << 8;
				c = nz & 1;
				nz >>= 1;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				break;
			case 108:
				if ((addr & 255) == 255)
					pc = (asap.memory[addr] & 0xff) + ((asap.memory[addr - 255] & 0xff) << 8);
				else
					pc = (asap.memory[addr] & 0xff) + ((asap.memory[addr + 1] & 0xff) << 8);
				break;
			case 129:
			case 133:
			case 141:
			case 145:
			case 149:
			case 153:
			case 157:
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, a);
				else
					asap.memory[addr] = (byte) a;
				break;
			case 131:
			case 135:
			case 143:
			case 151:
				data = a & x;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, data);
				else
					asap.memory[addr] = (byte) data;
				break;
			case 132:
			case 140:
			case 148:
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, y);
				else
					asap.memory[addr] = (byte) y;
				break;
			case 134:
			case 142:
			case 150:
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, x);
				else
					asap.memory[addr] = (byte) x;
				break;
			case 160:
			case 164:
			case 172:
			case 180:
			case 188:
				nz = y = (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				break;
			case 161:
			case 165:
			case 169:
			case 173:
			case 177:
			case 181:
			case 185:
			case 189:
				nz = a = (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				break;
			case 162:
			case 166:
			case 174:
			case 182:
			case 190:
				nz = x = (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				break;
			case 163:
			case 167:
			case 175:
			case 179:
			case 183:
			case 191:
				nz = x = a = (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				break;
			case 187:
				nz = x = a = s &= (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				break;
			case 192:
			case 196:
			case 204:
				nz = (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				c = y >= nz ? 1 : 0;
				nz = y - nz & 255;
				break;
			case 193:
			case 197:
			case 201:
			case 205:
			case 209:
			case 213:
			case 217:
			case 221:
				nz = (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				c = a >= nz ? 1 : 0;
				nz = a - nz & 255;
				break;
			case 195:
			case 199:
			case 207:
			case 211:
			case 215:
			case 219:
			case 223:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				nz = nz - 1 & 255;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				c = a >= nz ? 1 : 0;
				nz = a - nz & 255;
				break;
			case 198:
			case 206:
			case 214:
			case 222:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				nz = nz - 1 & 255;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				break;
			case 224:
			case 228:
			case 236:
				nz = (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				c = x >= nz ? 1 : 0;
				nz = x - nz & 255;
				break;
			case 225:
			case 229:
			case 233:
			case 235:
			case 237:
			case 241:
			case 245:
			case 249:
			case 253:
				data = (addr & 63744) == 53248 ? asap.peekHardware(addr) : asap.memory[addr] & 0xff;
				{
					int tmp = a - data - 1 + c;
					int al = (a & 15) - (data & 15) - 1 + c;
					vdi = (vdi & 12) + (((data ^ a) & (a ^ tmp)) >> 1 & 64);
					c = tmp >= 0 ? 1 : 0;
					nz = a = tmp & 255;
					if ((vdi & 8) != 0) {
						if (al < 0)
							a += al < -10 ? 10 : -6;
						if (c == 0)
							a = a - 96 & 255;
					}
				}
				break;
			case 227:
			case 231:
			case 239:
			case 243:
			case 247:
			case 251:
			case 255:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				nz = nz + 1 & 255;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				data = nz;
				{
					int tmp = a - data - 1 + c;
					int al = (a & 15) - (data & 15) - 1 + c;
					vdi = (vdi & 12) + (((data ^ a) & (a ^ tmp)) >> 1 & 64);
					c = tmp >= 0 ? 1 : 0;
					nz = a = tmp & 255;
					if ((vdi & 8) != 0) {
						if (al < 0)
							a += al < -10 ? 10 : -6;
						if (c == 0)
							a = a - 96 & 255;
					}
				}
				break;
			case 230:
			case 238:
			case 246:
			case 254:
				if (addr >> 8 == 210) {
					asap.cycle--;
					nz = asap.peekHardware(addr);
					asap.pokeHardware(addr, nz);
					asap.cycle++;
				}
				else
					nz = asap.memory[addr] & 0xff;
				nz = nz + 1 & 255;
				if ((addr & 63744) == 53248)
					asap.pokeHardware(addr, nz);
				else
					asap.memory[addr] = (byte) nz;
				break;
			}
		}
		this.pc = pc;
		this.nz = nz;
		this.a = a;
		this.x = x;
		this.y = y;
		this.c = c;
		this.s = s;
		this.vdi = vdi;
	}
	int nz;
	int pc;
	int s;
	int vdi;
	int x;
	int y;
	private static final int[] CI_CONST_ARRAY_1 = { 7, 6, 2, 8, 3, 3, 5, 5, 3, 2, 2, 2, 4, 4, 6, 6,
		2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7,
		6, 6, 2, 8, 3, 3, 5, 5, 4, 2, 2, 2, 4, 4, 6, 6,
		2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7,
		6, 6, 2, 8, 3, 3, 5, 5, 3, 2, 2, 2, 3, 4, 6, 6,
		2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7,
		6, 6, 2, 8, 3, 3, 5, 5, 4, 2, 2, 2, 5, 4, 6, 6,
		2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7,
		2, 6, 2, 6, 3, 3, 3, 3, 2, 2, 2, 2, 4, 4, 4, 4,
		2, 6, 2, 6, 4, 4, 4, 4, 2, 5, 2, 5, 5, 5, 5, 5,
		2, 6, 2, 6, 3, 3, 3, 3, 2, 2, 2, 2, 4, 4, 4, 4,
		2, 5, 2, 5, 4, 4, 4, 4, 2, 4, 2, 4, 4, 4, 4, 4,
		2, 6, 2, 8, 3, 3, 5, 5, 2, 2, 2, 2, 4, 4, 6, 6,
		2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7,
		2, 6, 2, 8, 3, 3, 5, 5, 2, 2, 2, 2, 4, 4, 6, 6,
		2, 5, 2, 8, 4, 4, 6, 6, 2, 4, 2, 7, 4, 4, 7, 7 };
}
