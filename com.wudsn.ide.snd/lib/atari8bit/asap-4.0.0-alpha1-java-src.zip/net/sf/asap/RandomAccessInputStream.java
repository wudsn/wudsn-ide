// Generated automatically with "cito". Do not edit.
package net.sf.asap;

public interface RandomAccessInputStream
{
	boolean run(int offset, byte[] buffer, int length);
}
