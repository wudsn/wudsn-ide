// Generated automatically with "cito". Do not edit.
package net.sf.asap;

public interface StringConsumer
{
	void run(String s);
}
