// Generated automatically with "cito". Do not edit.
package net.sf.asap;

class PokeyPair
{
	public PokeyPair()
	{
		int reg = 511;
		for (int i = 0; i < 511; i++) {
			reg = (((reg >> 5 ^ reg) & 1) << 8) + (reg >> 1);
			this.poly9Lookup[i] = (byte) reg;
		}
		reg = 131071;
		for (int i = 0; i < 16385; i++) {
			reg = (((reg >> 5 ^ reg) & 255) << 9) + (reg >> 8);
			this.poly17Lookup[i] = (byte) (reg >> 1);
		}
	}
	final Pokey basePokey = new Pokey();

	final int endFrame(int cycle)
	{
		this.basePokey.endFrame(this, cycle);
		if (this.extraPokeyMask != 0)
			this.extraPokey.endFrame(this, cycle);
		this.sampleOffset += cycle * this.sampleFactor;
		this.readySamplesStart = 0;
		this.readySamplesEnd = this.sampleOffset >> 20;
		this.sampleOffset &= 1048575;
		return this.readySamplesEnd;
	}
	final Pokey extraPokey = new Pokey();
	private int extraPokeyMask;

	/**
	 * Fills buffer with samples from <code>DeltaBuffer</code>.
	 */
	final int generate(byte[] buffer, int bufferOffset, int blocks, int format)
	{
		int i = this.readySamplesStart;
		int samplesEnd = this.readySamplesEnd;
		if (blocks < samplesEnd - i)
			samplesEnd = i + blocks;
		else
			blocks = samplesEnd - i;
		int accLeft = this.iirAccLeft;
		int accRight = this.iirAccRight;
		for (; i < samplesEnd; i++) {
			accLeft += this.basePokey.deltaBuffer[i] - (accLeft * 3 >> 10);
			int sample = accLeft >> 11;
			if (sample < -32767)
				sample = -32767;
			else if (sample > 32767)
				sample = 32767;
			switch (format) {
			case ASAPSampleFormat.U8:
				buffer[bufferOffset++] = (byte) ((sample >> 8) + 128);
				break;
			case ASAPSampleFormat.S16_L_E:
				buffer[bufferOffset++] = (byte) sample;
				buffer[bufferOffset++] = (byte) (sample >> 8);
				break;
			case ASAPSampleFormat.S16_B_E:
				buffer[bufferOffset++] = (byte) (sample >> 8);
				buffer[bufferOffset++] = (byte) sample;
				break;
			}
			if (this.extraPokeyMask != 0) {
				accRight += this.extraPokey.deltaBuffer[i] - (accRight * 3 >> 10);
				sample = accRight >> 11;
				if (sample < -32767)
					sample = -32767;
				else if (sample > 32767)
					sample = 32767;
				switch (format) {
				case ASAPSampleFormat.U8:
					buffer[bufferOffset++] = (byte) ((sample >> 8) + 128);
					break;
				case ASAPSampleFormat.S16_L_E:
					buffer[bufferOffset++] = (byte) sample;
					buffer[bufferOffset++] = (byte) (sample >> 8);
					break;
				case ASAPSampleFormat.S16_B_E:
					buffer[bufferOffset++] = (byte) (sample >> 8);
					buffer[bufferOffset++] = (byte) sample;
					break;
				}
			}
		}
		if (i == this.readySamplesEnd) {
			accLeft += this.basePokey.deltaBuffer[i] + this.basePokey.deltaBuffer[i + 1];
			accRight += this.extraPokey.deltaBuffer[i] + this.extraPokey.deltaBuffer[i + 1];
		}
		this.readySamplesStart = i;
		this.iirAccLeft = accLeft;
		this.iirAccRight = accRight;
		return blocks;
	}
	private int iirAccLeft;
	private int iirAccRight;

	final void initialize(boolean ntsc, boolean stereo)
	{
		this.extraPokeyMask = stereo ? 16 : 0;
		this.basePokey.initialize();
		this.extraPokey.initialize();
		this.sampleFactor = ntsc ? 25837 : 26075;
		this.sampleOffset = 0;
		this.readySamplesStart = 0;
		this.readySamplesEnd = 0;
		this.iirAccLeft = 0;
		this.iirAccRight = 0;
	}

	final boolean isSilent()
	{
		return this.basePokey.isSilent() && this.extraPokey.isSilent();
	}

	final int peek(int addr, int cycle)
	{
		Pokey pokey = (addr & this.extraPokeyMask) != 0 ? this.extraPokey : this.basePokey;
		switch (addr & 15) {
		case 10:
			if (pokey.init)
				return 255;
			int i = cycle + pokey.polyIndex;
			if ((pokey.audctl & 128) != 0)
				return this.poly9Lookup[i % 511] & 0xff;
			i %= 131071;
			int j = i >> 3;
			i &= 7;
			return ((this.poly17Lookup[j] & 0xff) >> i) + ((this.poly17Lookup[j + 1] & 0xff) << 8 - i) & 255;
		case 14:
			return pokey.irqst;
		default:
			return 255;
		}
	}

	final int poke(int addr, int data, int cycle)
	{
		Pokey pokey = (addr & this.extraPokeyMask) != 0 ? this.extraPokey : this.basePokey;
		return pokey.poke(this, addr, data, cycle);
	}
	final byte[] poly17Lookup = new byte[16385];
	final byte[] poly9Lookup = new byte[511];
	int readySamplesEnd;
	int readySamplesStart;
	int sampleFactor;
	int sampleOffset;

	final void startFrame()
	{
		clear(this.basePokey.deltaBuffer);
		if (this.extraPokeyMask != 0)
			clear(this.extraPokey.deltaBuffer);
	}
	private static void clear(int[] array)
	{
		for (int i = 0; i < array.length; i++)
			array[i] = 0;
	}
}
