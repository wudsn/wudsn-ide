// Generated automatically with "cito". Do not edit.
package net.sf.asap;

/**
 * Static methods for writing modules in different formats.
 */
public class ASAPWriter
{

	/**
	 * Writes text representation of the given duration.
	 * Returns the number of bytes written to <code>result</code>.
	 * @param result The output buffer.
	 * @param value Number of milliseconds.
	 */
	public static int durationToString(byte[] result, int value)
	{
		if (!ASAPWriter.secondsToString(result, 0, value))
			return 0;
		value %= 1000;
		if (value == 0)
			return 5;
		result[5] = 46;
		ASAPWriter.twoDigitsToString(result, 6, value / 10);
		value %= 10;
		if (value == 0)
			return 8;
		result[8] = (byte) (48 + value);
		return 9;
	}

	/**
	 * Enumerates possible file types the given module can be written as.
	 * @param output Receives filename extensions without the leading dot.
	 * @param info File information.
	 * @param module Contents of the file.
	 * @param moduleLen Length of the file.
	 */
	public static void enumSaveExts(StringConsumer output, ASAPInfo info, byte[] module, int moduleLen)
	{
		switch (info.type) {
		case ASAPModuleType.SAP_B:
		case ASAPModuleType.SAP_C:
			output.run("sap");
			String ext = info.getOriginalModuleExt(module, moduleLen);
			if (ext != null)
				output.run(ext);
			output.run("xex");
			break;
		case ASAPModuleType.SAP_D:
			output.run("sap");
			if (info.fastplay == 312)
				output.run("xex");
			break;
		case ASAPModuleType.SAP_S:
			output.run("sap");
			break;
		default:
			output.run(info.getOriginalModuleExt(module, moduleLen));
			output.run("sap");
			output.run("xex");
			break;
		}
	}

	private static int formatXexInfoText(byte[] dest, int destLen, int endColumn, String src, boolean author)
	{
		int srcLen = src.length();
		for (int srcOffset = 0; srcOffset < srcLen;) {
			int c = src.charAt(srcOffset++);
			if (c == 32) {
				if (author && srcOffset < srcLen && src.charAt(srcOffset) == 38) {
					int authorLen;
					for (authorLen = 1; srcOffset + authorLen < srcLen; authorLen++) {
						if (src.charAt(srcOffset + authorLen) == 32 && srcOffset + authorLen + 1 < srcLen && src.charAt(srcOffset + authorLen + 1) == 38)
							break;
					}
					if (authorLen <= 32 && destLen % 32 + 1 + authorLen > 32) {
						destLen = ASAPWriter.padXexInfo(dest, destLen, 1);
						continue;
					}
				}
				int wordLen;
				for (wordLen = 0; srcOffset + wordLen < srcLen && src.charAt(srcOffset + wordLen) != 32; wordLen++) {
				}
				if (wordLen <= 32 && destLen % 32 + 1 + wordLen > 32) {
					destLen = ASAPWriter.padXexInfo(dest, destLen, 0);
					continue;
				}
			}
			dest[destLen++] = (byte) c;
		}
		return ASAPWriter.padXexInfo(dest, destLen, endColumn);
	}
	/**
	 * Maximum length of text representation of a duration.
	 * Corresponds to the longest format which is <code>"mm:ss.xxx"</code>.
	 */
	public static final int MAX_DURATION_LENGTH = 9;

	private static int padXexInfo(byte[] dest, int offset, int endColumn)
	{
		while (offset % 32 != endColumn)
			dest[offset++] = 32;
		return offset;
	}

	private static boolean secondsToString(byte[] result, int offset, int value)
	{
		if (value < 0 || value >= 6000000)
			return false;
		value /= 1000;
		ASAPWriter.twoDigitsToString(result, offset, value / 60);
		result[offset + 2] = 58;
		ASAPWriter.twoDigitsToString(result, offset + 3, value % 60);
		return true;
	}

	private static void twoDigitsToString(byte[] result, int offset, int value)
	{
		result[offset] = (byte) (48 + value / 10);
		result[offset + 1] = (byte) (48 + value % 10);
	}

	/**
	 * Writes the given module in a possibly different file format.
	 * @param targetFilename Output filename, used to determine the format.
	 * @param w Receives output file contents.
	 * @param info File information got from the source file with data updated for the output file.
	 * @param module Contents of the source file.
	 * @param moduleLen Length of the source file.
	 * @param tag Display information (xex output only).
	 */
	public static void write(String targetFilename, ByteWriter w, ASAPInfo info, byte[] module, int moduleLen, boolean tag) throws Exception
	{
		int destExt = ASAPInfo.getPackedExt(targetFilename);
		switch (destExt) {
		case 7364979:
			ASAPWriter.writeExecutable(w, null, info, module, moduleLen);
			return;
		case 7890296:
			{
				int[] initAndPlayer = new int[2];
				ASAPWriter.writeExecutable(w, initAndPlayer, info, module, moduleLen);
				switch (info.type) {
				case ASAPModuleType.SAP_D:
					if (info.fastplay != 312)
						throw new Exception("Impossible conversion");
					ASAPWriter.writeBytes(w, getBinaryResource("xexd.obx", 117), 2, 117);
					ASAPWriter.writeWord(w, initAndPlayer[0]);
					if (initAndPlayer[1] < 0) {
						w.run(96);
						w.run(96);
						w.run(96);
					}
					else {
						w.run(76);
						ASAPWriter.writeWord(w, initAndPlayer[1]);
					}
					w.run(info.defaultSong);
					break;
				case ASAPModuleType.SAP_S:
					throw new Exception("Impossible conversion");
				default:
					ASAPWriter.writeBytes(w, getBinaryResource("xexb.obx", 183), 2, 183);
					ASAPWriter.writeWord(w, initAndPlayer[0]);
					w.run(76);
					ASAPWriter.writeWord(w, initAndPlayer[1]);
					w.run(info.defaultSong);
					w.run(info.fastplay & 1);
					w.run((info.fastplay >> 1) % 156);
					w.run((info.fastplay >> 1) % 131);
					w.run(info.fastplay / 312);
					w.run(info.fastplay / 262);
					break;
				}
				if (tag)
					ASAPWriter.writeXexInfo(w, info);
				ASAPWriter.writeWord(w, 736);
				ASAPWriter.writeWord(w, 737);
				ASAPWriter.writeWord(w, tag ? 256 : 292);
				return;
			}
		default:
			String possibleExt = info.getOriginalModuleExt(module, moduleLen);
			if (possibleExt != null) {
				int packedPossibleExt = possibleExt.charAt(0) + (possibleExt.charAt(1) << 8) + (possibleExt.charAt(2) << 16) | 2105376;
				if (destExt == packedPossibleExt || destExt == 3698036 && packedPossibleExt == 6516084) {
					ASAPWriter.writeNative(w, info, module, moduleLen);
					return;
				}
			}
			throw new Exception("Impossible conversion");
		}
	}

	private static void writeBytes(ByteWriter w, byte[] array, int startIndex, int endIndex)
	{
		while (startIndex < endIndex)
			w.run(array[startIndex++] & 0xff);
	}

	private static void writeCmcInit(ByteWriter w, int[] initAndPlayer, ASAPInfo info)
	{
		if (initAndPlayer == null)
			return;
		ASAPWriter.writeWord(w, 4064);
		ASAPWriter.writeWord(w, 4080);
		w.run(72);
		w.run(162);
		w.run(info.music & 255);
		w.run(160);
		w.run(info.music >> 8);
		w.run(169);
		w.run(112);
		w.run(32);
		ASAPWriter.writeWord(w, initAndPlayer[1] + 3);
		ASAPWriter.writePlaTaxLda0(w);
		w.run(76);
		ASAPWriter.writeWord(w, initAndPlayer[1] + 3);
		initAndPlayer[0] = 4064;
		initAndPlayer[1] += 6;
	}

	private static void writeDec(ByteWriter w, int value)
	{
		if (value >= 10) {
			ASAPWriter.writeDec(w, value / 10);
			value %= 10;
		}
		w.run(48 + value);
	}

	private static void writeDecSapTag(ByteWriter w, String tag, int value)
	{
		ASAPWriter.writeString(w, tag);
		ASAPWriter.writeDec(w, value);
		w.run(13);
		w.run(10);
	}

	static void writeExecutable(ByteWriter w, int[] initAndPlayer, ASAPInfo info, byte[] module, int moduleLen) throws Exception
	{
		byte[] playerRoutine = ASAP6502.getPlayerRoutine(info);
		int player = -1;
		int playerLastByte = -1;
		if (playerRoutine != null) {
			player = ASAPInfo.getWord(playerRoutine, 2);
			playerLastByte = ASAPInfo.getWord(playerRoutine, 4);
			if (info.music <= playerLastByte)
				throw new Exception("Module address conflicts with the player routine");
		}
		int startAddr;
		switch (info.type) {
		case ASAPModuleType.SAP_B:
			ASAPWriter.writeExecutableFromSap(w, initAndPlayer, info, 66, module, moduleLen);
			break;
		case ASAPModuleType.SAP_C:
			ASAPWriter.writeExecutableFromSap(w, initAndPlayer, info, 67, module, moduleLen);
			ASAPWriter.writeCmcInit(w, initAndPlayer, info);
			break;
		case ASAPModuleType.SAP_D:
			ASAPWriter.writeExecutableFromSap(w, initAndPlayer, info, 68, module, moduleLen);
			break;
		case ASAPModuleType.SAP_S:
			ASAPWriter.writeExecutableFromSap(w, initAndPlayer, info, 83, module, moduleLen);
			break;
		case ASAPModuleType.CMC:
		case ASAPModuleType.CM3:
		case ASAPModuleType.CMR:
		case ASAPModuleType.CMS:
			ASAPWriter.writeExecutableHeader(w, initAndPlayer, info, 67, -1, player);
			w.run(255);
			w.run(255);
			ASAPWriter.writeBytes(w, module, 2, moduleLen);
			ASAPWriter.writeBytes(w, playerRoutine, 2, playerLastByte - player + 7);
			ASAPWriter.writeCmcInit(w, initAndPlayer, info);
			break;
		case ASAPModuleType.DLT:
			startAddr = ASAPWriter.writeExecutableHeaderForSongPos(w, initAndPlayer, info, player, 5, 7, 259);
			if (moduleLen == 11270) {
				ASAPWriter.writeBytes(w, module, 0, 4);
				ASAPWriter.writeWord(w, 19456);
				ASAPWriter.writeBytes(w, module, 6, moduleLen);
				w.run(0);
			}
			else
				ASAPWriter.writeBytes(w, module, 0, moduleLen);
			ASAPWriter.writeWord(w, startAddr);
			ASAPWriter.writeWord(w, playerLastByte);
			if (info.songs != 1) {
				ASAPWriter.writeBytes(w, info.songPos, 0, info.songs);
				w.run(170);
				w.run(188);
				ASAPWriter.writeWord(w, startAddr);
			}
			else {
				w.run(160);
				w.run(0);
			}
			w.run(76);
			ASAPWriter.writeWord(w, player + 256);
			ASAPWriter.writeBytes(w, playerRoutine, 6, playerLastByte - player + 7);
			break;
		case ASAPModuleType.MPT:
			startAddr = ASAPWriter.writeExecutableHeaderForSongPos(w, initAndPlayer, info, player, 13, 17, 3);
			ASAPWriter.writeBytes(w, module, 0, moduleLen);
			ASAPWriter.writeWord(w, startAddr);
			ASAPWriter.writeWord(w, playerLastByte);
			if (info.songs != 1) {
				ASAPWriter.writeBytes(w, info.songPos, 0, info.songs);
				w.run(72);
			}
			w.run(160);
			w.run(info.music & 255);
			w.run(162);
			w.run(info.music >> 8);
			w.run(169);
			w.run(0);
			w.run(32);
			ASAPWriter.writeWord(w, player);
			if (info.songs != 1) {
				w.run(104);
				w.run(168);
				w.run(190);
				ASAPWriter.writeWord(w, startAddr);
			}
			else {
				w.run(162);
				w.run(0);
			}
			w.run(169);
			w.run(2);
			ASAPWriter.writeBytes(w, playerRoutine, 6, playerLastByte - player + 7);
			break;
		case ASAPModuleType.RMT:
			ASAPWriter.writeExecutableHeader(w, initAndPlayer, info, 66, 3200, 1539);
			ASAPWriter.writeBytes(w, module, 0, ASAPInfo.getWord(module, 4) - info.music + 7);
			ASAPWriter.writeWord(w, 3200);
			if (info.songs != 1) {
				ASAPWriter.writeWord(w, 3210 + info.songs);
				w.run(168);
				w.run(185);
				ASAPWriter.writeWord(w, 3211);
			}
			else {
				ASAPWriter.writeWord(w, 3208);
				w.run(169);
				w.run(0);
			}
			w.run(162);
			w.run(info.music & 255);
			w.run(160);
			w.run(info.music >> 8);
			w.run(76);
			ASAPWriter.writeWord(w, 1536);
			if (info.songs != 1)
				ASAPWriter.writeBytes(w, info.songPos, 0, info.songs);
			ASAPWriter.writeBytes(w, playerRoutine, 2, playerLastByte - player + 7);
			break;
		case ASAPModuleType.TMC:
			int player2 = player + CI_CONST_ARRAY_1[(module[37] & 0xff) - 1];
			startAddr = player2 + CI_CONST_ARRAY_2[(module[37] & 0xff) - 1];
			if (info.songs != 1)
				startAddr -= 3;
			ASAPWriter.writeExecutableHeader(w, initAndPlayer, info, 66, startAddr, player2);
			ASAPWriter.writeBytes(w, module, 0, moduleLen);
			ASAPWriter.writeWord(w, startAddr);
			ASAPWriter.writeWord(w, playerLastByte);
			if (info.songs != 1)
				w.run(72);
			w.run(160);
			w.run(info.music & 255);
			w.run(162);
			w.run(info.music >> 8);
			w.run(169);
			w.run(112);
			w.run(32);
			ASAPWriter.writeWord(w, player);
			if (info.songs != 1)
				ASAPWriter.writePlaTaxLda0(w);
			else {
				w.run(169);
				w.run(96);
			}
			switch (module[37]) {
			case 2:
				w.run(6);
				w.run(0);
				w.run(76);
				ASAPWriter.writeWord(w, player);
				w.run(165);
				w.run(0);
				w.run(230);
				w.run(0);
				w.run(74);
				w.run(144);
				w.run(5);
				w.run(176);
				w.run(6);
				break;
			case 3:
			case 4:
				w.run(160);
				w.run(1);
				w.run(132);
				w.run(0);
				w.run(208);
				w.run(10);
				w.run(198);
				w.run(0);
				w.run(208);
				w.run(12);
				w.run(160);
				w.run(module[37] & 0xff);
				w.run(132);
				w.run(0);
				w.run(208);
				w.run(3);
				break;
			}
			ASAPWriter.writeBytes(w, playerRoutine, 6, playerLastByte - player + 7);
			break;
		case ASAPModuleType.TM2:
			ASAPWriter.writeExecutableHeader(w, initAndPlayer, info, 66, 4992, 2051);
			ASAPWriter.writeBytes(w, module, 0, moduleLen);
			ASAPWriter.writeWord(w, 4992);
			if (info.songs != 1) {
				ASAPWriter.writeWord(w, 5008);
				w.run(72);
			}
			else
				ASAPWriter.writeWord(w, 5006);
			w.run(160);
			w.run(info.music & 255);
			w.run(162);
			w.run(info.music >> 8);
			w.run(169);
			w.run(112);
			w.run(32);
			ASAPWriter.writeWord(w, 2048);
			if (info.songs != 1)
				ASAPWriter.writePlaTaxLda0(w);
			else {
				w.run(169);
				w.run(0);
				w.run(170);
			}
			w.run(76);
			ASAPWriter.writeWord(w, 2048);
			ASAPWriter.writeBytes(w, playerRoutine, 2, playerLastByte - player + 7);
			break;
		case ASAPModuleType.FC:
			ASAPWriter.writeExecutableHeader(w, initAndPlayer, info, 66, player, player + 3);
			ASAPWriter.writeWord(w, 65535);
			ASAPWriter.writeWord(w, info.music);
			ASAPWriter.writeWord(w, info.music + moduleLen - 1);
			ASAPWriter.writeBytes(w, module, 0, moduleLen);
			ASAPWriter.writeBytes(w, playerRoutine, 2, playerLastByte - player + 7);
			break;
		}
	}

	private static void writeExecutableFromSap(ByteWriter w, int[] initAndPlayer, ASAPInfo info, int type, byte[] module, int moduleLen)
	{
		ASAPWriter.writeExecutableHeader(w, initAndPlayer, info, type, info.init, info.player);
		ASAPWriter.writeBytes(w, module, info.headerLen, moduleLen);
	}

	private static void writeExecutableHeader(ByteWriter w, int[] initAndPlayer, ASAPInfo info, int type, int init, int player)
	{
		if (initAndPlayer == null)
			ASAPWriter.writeSapHeader(w, info, type, init, player);
		else {
			initAndPlayer[0] = init;
			initAndPlayer[1] = player;
		}
	}

	private static int writeExecutableHeaderForSongPos(ByteWriter w, int[] initAndPlayer, ASAPInfo info, int player, int codeForOneSong, int codeForManySongs, int playerOffset)
	{
		if (info.songs != 1) {
			ASAPWriter.writeExecutableHeader(w, initAndPlayer, info, 66, player - codeForManySongs, player + playerOffset);
			return player - codeForManySongs - info.songs;
		}
		ASAPWriter.writeExecutableHeader(w, initAndPlayer, info, 66, player - codeForOneSong, player + playerOffset);
		return player - codeForOneSong;
	}

	private static void writeHexSapTag(ByteWriter w, String tag, int value)
	{
		if (value < 0)
			return;
		ASAPWriter.writeString(w, tag);
		for (int i = 12; i >= 0; i -= 4) {
			int digit = value >> i & 15;
			w.run(digit + (digit < 10 ? 48 : 55));
		}
		w.run(13);
		w.run(10);
	}

	private static void writeNative(ByteWriter w, ASAPInfo info, byte[] module, int moduleLen) throws Exception
	{
		int diff;
		switch (info.type) {
		case ASAPModuleType.SAP_B:
		case ASAPModuleType.SAP_C:
			int offset = info.getRmtSapOffset(module, moduleLen);
			if (offset > 0) {
				w.run(255);
				w.run(255);
				ASAPWriter.writeBytes(w, module, offset, moduleLen);
				break;
			}
			int blockLen = ASAPInfo.getWord(module, info.headerLen + 4) - ASAPInfo.getWord(module, info.headerLen + 2) + 7;
			if (blockLen < 7 || info.headerLen + blockLen >= moduleLen)
				throw new Exception("Cannot extract module from SAP");
			if (info.init == 1024 && info.player == 1027)
				ASAPWriter.writeBytes(w, module, info.headerLen + 6, info.headerLen + blockLen);
			else
				ASAPWriter.writeBytes(w, module, info.headerLen, info.headerLen + blockLen);
			break;
		case ASAPModuleType.CMC:
		case ASAPModuleType.CM3:
		case ASAPModuleType.CMR:
		case ASAPModuleType.CMS:
			diff = ASAPWriter.writeNativeHeader(w, info, module);
			ASAPWriter.writeBytes(w, module, 6, 26);
			ASAPWriter.writeRelocatedLowHigh(w, diff, module, 26, 64);
			ASAPWriter.writeBytes(w, module, 154, moduleLen);
			break;
		case ASAPModuleType.DLT:
			diff = ASAPWriter.writeNativeHeader(w, info, module);
			ASAPWriter.writeBytes(w, module, 6, moduleLen);
			break;
		case ASAPModuleType.MPT:
			diff = ASAPWriter.writeNativeHeader(w, info, module);
			ASAPWriter.writeRelocatedWords(w, diff, module, 6, 192);
			ASAPWriter.writeBytes(w, module, 198, 454);
			ASAPWriter.writeRelocatedLowHigh(w, diff, module, 454, 4);
			ASAPWriter.writeBytes(w, module, 462, moduleLen);
			break;
		case ASAPModuleType.RMT:
			diff = ASAPWriter.writeNativeHeader(w, info, module);
			ASAPWriter.writeBytes(w, module, 6, 14);
			int music = ASAPInfo.getWord(module, 2);
			int patternLowAddress = ASAPInfo.getWord(module, 16);
			int pointersAndInstrumentsLen = patternLowAddress - music - 8;
			ASAPWriter.writeRelocatedWords(w, diff, module, 14, pointersAndInstrumentsLen);
			int patterns = ASAPInfo.getWord(module, 18) - patternLowAddress;
			ASAPWriter.writeRelocatedLowHigh(w, diff, module, 14 + pointersAndInstrumentsLen, patterns);
			int songOffset = 6 + ASAPInfo.getWord(module, 20) - music;
			ASAPWriter.writeBytes(w, module, 14 + pointersAndInstrumentsLen + (patterns << 1), songOffset);
			int songEnd = 7 + ASAPInfo.getWord(module, 4) - music;
			while (songOffset + 3 < songEnd) {
				int nextSongOffset = songOffset + (module[9] & 0xff) - 48;
				if (module[songOffset] == -2) {
					w.run(254);
					w.run(module[songOffset + 1] & 0xff);
					ASAPWriter.writeWord(w, ASAPInfo.getWord(module, songOffset + 2) + diff);
					songOffset += 4;
				}
				if (nextSongOffset > songEnd)
					nextSongOffset = songEnd;
				ASAPWriter.writeBytes(w, module, songOffset, nextSongOffset);
				songOffset = nextSongOffset;
			}
			ASAPWriter.writeBytes(w, module, songOffset, songEnd);
			if (moduleLen >= songEnd + 5) {
				ASAPWriter.writeRelocatedWords(w, diff, module, songEnd, 4);
				ASAPWriter.writeBytes(w, module, songEnd + 4, moduleLen);
			}
			break;
		case ASAPModuleType.TMC:
			diff = ASAPWriter.writeNativeHeader(w, info, module);
			ASAPWriter.writeBytes(w, module, 6, 38);
			ASAPWriter.writeRelocatedLowHigh(w, diff, module, 38, 64);
			ASAPWriter.writeRelocatedLowHigh(w, diff, module, 166, 128);
			ASAPWriter.writeBytes(w, module, 422, moduleLen);
			break;
		case ASAPModuleType.TM2:
			diff = ASAPWriter.writeNativeHeader(w, info, module);
			ASAPWriter.writeBytes(w, module, 6, 134);
			ASAPWriter.writeRelocatedBytes(w, diff, module, 134, 774, 128, 0);
			ASAPWriter.writeRelocatedLowHigh(w, diff, module, 262, 256);
			ASAPWriter.writeRelocatedBytes(w, diff, module, 134, 774, 128, 8);
			ASAPWriter.writeBytes(w, module, 902, moduleLen);
			break;
		case ASAPModuleType.FC:
			ASAPWriter.writeBytes(w, module, 0, moduleLen);
			break;
		default:
			throw new Exception("Impossible conversion");
		}
	}

	private static int writeNativeHeader(ByteWriter w, ASAPInfo info, byte[] module) throws Exception
	{
		int diff = info.music - ASAPInfo.getWord(module, 2);
		int last = ASAPInfo.getWord(module, 4) + diff;
		if (last > 65535)
			throw new Exception("Address set too high");
		w.run(255);
		w.run(255);
		ASAPWriter.writeWord(w, info.music);
		ASAPWriter.writeWord(w, last);
		return diff;
	}

	private static void writePlaTaxLda0(ByteWriter w)
	{
		w.run(104);
		w.run(170);
		w.run(169);
		w.run(0);
	}

	private static void writeRelocatedBytes(ByteWriter w, int diff, byte[] module, int lowOffset, int highOffset, int len, int shift)
	{
		for (int i = 0; i < len; i++) {
			int address = (module[lowOffset + i] & 0xff) + ((module[highOffset + i] & 0xff) << 8);
			if (address != 0 && address != 65535)
				address += diff;
			w.run(address >> shift & 255);
		}
	}

	private static void writeRelocatedLowHigh(ByteWriter w, int diff, byte[] module, int lowOffset, int len)
	{
		ASAPWriter.writeRelocatedBytes(w, diff, module, lowOffset, lowOffset + len, len, 0);
		ASAPWriter.writeRelocatedBytes(w, diff, module, lowOffset, lowOffset + len, len, 8);
	}

	private static void writeRelocatedWords(ByteWriter w, int diff, byte[] module, int offset, int len)
	{
		for (int i = 0; i < len; i += 2) {
			int address = (module[offset + i] & 0xff) + ((module[offset + i + 1] & 0xff) << 8);
			if (address != 0 && address != 65535)
				address += diff;
			ASAPWriter.writeWord(w, address);
		}
	}

	private static void writeSapHeader(ByteWriter w, ASAPInfo info, int type, int init, int player)
	{
		ASAPWriter.writeString(w, "SAP\r\n");
		ASAPWriter.writeTextSapTag(w, "AUTHOR ", info.author);
		ASAPWriter.writeTextSapTag(w, "NAME ", info.title);
		ASAPWriter.writeTextSapTag(w, "DATE ", info.date);
		if (info.songs > 1) {
			ASAPWriter.writeDecSapTag(w, "SONGS ", info.songs);
			if (info.defaultSong > 0)
				ASAPWriter.writeDecSapTag(w, "DEFSONG ", info.defaultSong);
		}
		if (info.channels > 1)
			ASAPWriter.writeString(w, "STEREO\r\n");
		if (info.ntsc)
			ASAPWriter.writeString(w, "NTSC\r\n");
		ASAPWriter.writeString(w, "TYPE ");
		w.run(type);
		w.run(13);
		w.run(10);
		if (info.fastplay != 312 || info.ntsc)
			ASAPWriter.writeDecSapTag(w, "FASTPLAY ", info.fastplay);
		if (type == 67)
			ASAPWriter.writeHexSapTag(w, "MUSIC ", info.music);
		ASAPWriter.writeHexSapTag(w, "INIT ", init);
		ASAPWriter.writeHexSapTag(w, "PLAYER ", player);
		ASAPWriter.writeHexSapTag(w, "COVOX ", info.covoxAddr);
		for (int song = 0; song < info.songs; song++) {
			if (info.durations[song] < 0)
				break;
			ASAPWriter.writeString(w, "TIME ");
			byte[] s = new byte[9];
			ASAPWriter.writeBytes(w, s, 0, ASAPWriter.durationToString(s, info.durations[song]));
			if (info.loops[song])
				ASAPWriter.writeString(w, " LOOP");
			w.run(13);
			w.run(10);
		}
	}

	private static void writeString(ByteWriter w, String s)
	{
		int n = s.length();
		for (int i = 0; i < n; i++)
			w.run(s.charAt(i));
	}

	private static void writeTextSapTag(ByteWriter w, String tag, String value)
	{
		ASAPWriter.writeString(w, tag);
		w.run(34);
		if (value.length() == 0)
			value = "<?>";
		ASAPWriter.writeString(w, value);
		w.run(34);
		w.run(13);
		w.run(10);
	}

	private static void writeWord(ByteWriter w, int value)
	{
		w.run(value & 255);
		w.run(value >> 8 & 255);
	}

	private static void writeXexInfo(ByteWriter w, ASAPInfo info)
	{
		byte[] title = new byte[256];
		int titleLen = ASAPWriter.formatXexInfoText(title, 0, 0, info.title.length() == 0 ? "(untitled)" : info.title, false);
		byte[] author = new byte[256];
		int authorLen;
		if (info.author.length() > 0) {
			author[0] = 98;
			author[1] = 121;
			author[2] = 32;
			authorLen = ASAPWriter.formatXexInfoText(author, 3, 0, info.author, true);
		}
		else
			authorLen = 0;
		byte[] other = new byte[256];
		int otherLen = ASAPWriter.formatXexInfoText(other, 0, 19, info.date, false);
		otherLen = ASAPWriter.formatXexInfoText(other, otherLen, 27, info.channels > 1 ? " STEREO" : "   MONO", false);
		int duration = info.durations[info.defaultSong];
		if (duration > 0 && ASAPWriter.secondsToString(other, otherLen, duration + 999))
			otherLen += 5;
		else
			otherLen = ASAPWriter.padXexInfo(other, otherLen, 0);
		int totalCharacters = titleLen + authorLen + otherLen;
		int totalLines = totalCharacters / 32;
		int otherAddress = 64592 - otherLen;
		int titleAddress = otherAddress - authorLen - 8 - titleLen;
		ASAPWriter.writeWord(w, titleAddress);
		ASAPWriter.writeBytes(w, getBinaryResource("xexinfo.obx", 178), 4, 6);
		ASAPWriter.writeBytes(w, title, 0, titleLen);
		for (int i = 0; i < 8; i++)
			w.run(85);
		ASAPWriter.writeBytes(w, author, 0, authorLen);
		ASAPWriter.writeBytes(w, other, 0, otherLen);
		for (int i = totalLines; i < 26; i++)
			w.run(112);
		w.run(48);
		ASAPWriter.writeXexInfoTextDl(w, titleAddress, titleLen, titleLen - 32);
		w.run(8);
		w.run(0);
		for (int i = 0; i < authorLen; i += 32)
			w.run(2);
		w.run(16);
		for (int i = 0; i < otherLen; i += 32)
			w.run(2);
		ASAPWriter.writeBytes(w, getBinaryResource("xexinfo.obx", 178), 6, 178);
	}

	private static void writeXexInfoTextDl(ByteWriter w, int address, int len, int verticalScrollAt)
	{
		w.run(verticalScrollAt == 0 ? 98 : 66);
		ASAPWriter.writeWord(w, address);
		for (int i = 32; i < len; i += 32)
			w.run(i == verticalScrollAt ? 34 : 2);
	}

	private static byte[] getBinaryResource(String name, int length)
	{
		java.io.DataInputStream dis = new java.io.DataInputStream(ASAPWriter.class.getResourceAsStream(name));
		byte[] result = new byte[length];
		try {
			try {
				dis.readFully(result);
			}
			finally {
				dis.close();
			}
		}
		catch (java.io.IOException e) {
			throw new RuntimeException();
		}
		return result;
	}
	private static final int[] CI_CONST_ARRAY_1 = { 3, -9, -10, -10 };
	private static final int[] CI_CONST_ARRAY_2 = { -14, -16, -17, -17 };
}
