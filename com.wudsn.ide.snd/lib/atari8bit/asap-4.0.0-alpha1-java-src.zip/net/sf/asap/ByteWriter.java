// Generated automatically with "cito". Do not edit.
package net.sf.asap;

public interface ByteWriter
{
	void run(int data);
}
