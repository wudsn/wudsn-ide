// Generated automatically with "cito". Do not edit.
package net.sf.asap;

/**
 * ATR disk image reader.
 */
public class AATR
{
	private int bytesPerSector;
	private RandomAccessInputStream content;
	private final byte[] directorySector = new byte[128];
	private int fileNo;
	private String filename;

	private int getFilenamePart(int directoryOffset, int maxLength)
	{
		for (int length = 0; length < maxLength; length++) {
			int c = this.directorySector[directoryOffset + length] & 0xff;
			if (c == 32) {
				int result = length;
				while (++length < maxLength) {
					if (this.directorySector[directoryOffset + length] != 32)
						return -1;
				}
				return result;
			}
			if (c >= 65 && c <= 90 || c >= 48 && c <= 57 || c == 95)
				continue;
			return -1;
		}
		return maxLength;
	}

	/**
	 * Advances to the next file on the open disk image.
	 * Returns the filename or <code>null</code> if no more files found.
	 */
	public final String nextFile()
	{
		for (;;) {
			if (this.fileNo >= 63)
				return null;
			this.fileNo++;
			int directoryOffset = (this.fileNo & 7) << 4;
			if (directoryOffset == 0 && !this.readSector(361 + (this.fileNo >> 3), this.directorySector, 128))
				return null;
			switch (this.directorySector[directoryOffset] & 215) {
			case 0:
				return null;
			case 66:
			case 70:
			case 3:
				break;
			default:
				continue;
			}
			int filenameLength = this.getFilenamePart(directoryOffset + 5, 8);
			if (filenameLength < 0)
				continue;
			int extLength = this.getFilenamePart(directoryOffset + 13, 3);
			if (extLength < 0 || filenameLength == 0 && extLength == 0)
				continue;
			this.filename = new String(this.directorySector, directoryOffset + 5, filenameLength);
			if (extLength > 0) {
				this.directorySector[directoryOffset + 12] = 46;
				String ext = new String(this.directorySector, directoryOffset + 12, 1 + extLength);
				this.filename += ext;
			}
			return this.filename;
		}
	}

	/**
	 * Opens an ATR disk image.
	 * Returns <code>true</code> on success.
	 */
	public final boolean open(RandomAccessInputStream content)
	{
		byte[] header = new byte[6];
		content.run(0, header, 6);
		if (header[0] != -106 || header[1] != 2)
			return false;
		this.bytesPerSector = header[4] & 0xff | (header[5] & 0xff) << 8;
		this.sector4Offset = 400;
		switch (this.bytesPerSector) {
		case 128:
			break;
		case 256:
			if ((header[2] & 15) == 0)
				this.sector4Offset = 784;
			break;
		default:
			return false;
		}
		this.content = content;
		this.fileNo = -1;
		return true;
	}

	/**
	 * Reads the current file.
	 * Returns the number of bytes read or -1 on error.
	 * @param buffer Destination buffer.
	 * @param length Maximum number of bytes to read.
	 */
	public final int readCurrentFile(byte[] buffer, int length)
	{
		int result = 0;
		int directoryOffset = (this.fileNo & 7) << 4;
		int sectorNo = this.directorySector[directoryOffset + 3] & 0xff | (this.directorySector[directoryOffset + 4] & 0xff) << 8;
		boolean myDos = (this.directorySector[directoryOffset] & 4) != 0;
		byte[] sector = new byte[256];
		while (sectorNo != 0 && length > 0) {
			if (!this.readSector(sectorNo, sector, this.bytesPerSector))
				return -1;
			int used = sector[this.bytesPerSector - 1] & 0xff;
			if (used > length)
				used = length;
			if (buffer != null)
				System.arraycopy(sector, 0, buffer, result, used);
			result += used;
			length -= used;
			sectorNo = sector[this.bytesPerSector - 3] & 0xff;
			if (!myDos)
				sectorNo &= 3;
			sectorNo = sectorNo << 8 | sector[this.bytesPerSector - 2] & 0xff;
		}
		return result;
	}

	/**
	 * Reads the given file from the open disk image.
	 * Returns the number of bytes read or -1 on error.
	 * @param filename Name of file to read.
	 * @param buffer Destination buffer.
	 * @param length Maximum number of bytes to read.
	 */
	public final int readFile(String filename, byte[] buffer, int length)
	{
		for (;;) {
			String currentFilename = this.nextFile();
			if (currentFilename == null)
				return -1;
			if (currentFilename.equals(filename))
				return this.readCurrentFile(buffer, length);
		}
	}

	private boolean readSector(int sectorNo, byte[] buffer, int length)
	{
		if (sectorNo < 4)
			return false;
		return this.content.run(this.sector4Offset + (sectorNo - 4) * this.bytesPerSector, buffer, length);
	}
	private int sector4Offset;
}
