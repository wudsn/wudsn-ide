// Generated automatically with "fut". Do not edit.
package net.sf.asap;

/**
 * Static methods for writing modules in different formats.
 */
public class ASAPWriter
{
	public ASAPWriter()
	{
	}

	/**
	 * Maximum number of extensions returned by <code>GetSaveExts</code>.
	 */
	public static final int MAX_SAVE_EXTS = 3;

	/**
	 * Enumerates possible file types the given module can be written as.
	 * Returns the number of extensions written to <code>exts</code>.
	 * @param exts Receives filename extensions without the leading dot.
	 * @param info File information.
	 * @param module Contents of the file.
	 * @param moduleLen Length of the file.
	 */
	public static int getSaveExts(String[] exts, ASAPInfo info, byte[] module, int moduleLen)
	{
		int i = 0;
		switch (info.type) {
		case SAP_B:
		case SAP_C:
			exts[i++] = "sap";
			String ext = info.getOriginalModuleExt(module, moduleLen);
			if (ext != null)
				exts[i++] = ext;
			exts[i++] = "xex";
			break;
		case SAP_D:
			exts[i++] = "sap";
			if (info.getPlayerRateScanlines() == 312)
				exts[i++] = "xex";
			break;
		case SAP_S:
			exts[i++] = "sap";
			break;
		default:
			exts[i++] = info.getOriginalModuleExt(module, moduleLen);
			exts[i++] = "sap";
			exts[i++] = "xex";
			break;
		}
		return i;
	}

	private static void twoDigitsToString(byte[] result, int offset, int value)
	{
		result[offset] = (byte) ('0' + value / 10);
		result[offset + 1] = (byte) ('0' + value % 10);
	}

	private static boolean secondsToString(byte[] result, int offset, int value)
	{
		if (value < 0 || value >= 6000000)
			return false;
		value /= 1000;
		twoDigitsToString(result, offset, value / 60);
		result[offset + 2] = ':';
		twoDigitsToString(result, offset + 3, value % 60);
		return true;
	}

	/**
	 * Maximum length of text representation of a duration.
	 * Corresponds to the longest format which is <code>"mm:ss.xxx"</code>.
	 */
	public static final int MAX_DURATION_LENGTH = 9;

	/**
	 * Writes text representation of the given duration.
	 * Returns the number of bytes written to <code>result</code>.
	 * @param result The output buffer.
	 * @param value Number of milliseconds.
	 */
	public static int durationToString(byte[] result, int value)
	{
		if (!secondsToString(result, 0, value))
			return 0;
		value %= 1000;
		if (value == 0)
			return 5;
		result[5] = '.';
		twoDigitsToString(result, 6, value / 10);
		value %= 10;
		if (value == 0)
			return 8;
		result[8] = (byte) ('0' + value);
		return 9;
	}
	byte[] output;
	int outputOffset;
	private int outputEnd;

	/**
	 * Sets the destination array for <code>Write</code>.
	 * @param output The destination array.
	 * @param startIndex The array offset to start writing at.
	 * @param endIndex The array offset to finish writing before.
	 */
	public final void setOutput(byte[] output, int startIndex, int endIndex)
	{
		this.output = output;
		this.outputOffset = startIndex;
		this.outputEnd = endIndex;
	}

	final void writeByte(int value) throws ASAPConversionException
	{
		if (this.outputOffset >= this.outputEnd)
			throw new ASAPConversionException("Output full");
		this.output[this.outputOffset++] = (byte) value;
	}

	final void writeWord(int value) throws ASAPConversionException
	{
		writeByte(value & 255);
		writeByte(value >> 8);
	}

	final void writeBytes(byte[] array, int startIndex, int endIndex) throws ASAPConversionException
	{
		int length = endIndex - startIndex;
		if (this.outputOffset + length > this.outputEnd)
			throw new ASAPConversionException("Output full");
		System.arraycopy(array, startIndex, this.output, this.outputOffset, length);
		this.outputOffset += length;
	}

	private void writeString(String s) throws ASAPConversionException
	{
		for (int _i = 0; _i < s.length(); _i++) {
			int c = s.charAt(_i);
			writeByte(c);
		}
	}

	private void writeDec(int value) throws ASAPConversionException
	{
		if (value >= 10) {
			writeDec(value / 10);
			value %= 10;
		}
		writeByte('0' + value);
	}

	private void writeTextSapTag(String tag, String value) throws ASAPConversionException
	{
		writeString(tag);
		writeByte('"');
		if (value.length() == 0)
			value = "<?>";
		writeString(value);
		writeByte('"');
		writeByte('\r');
		writeByte('\n');
	}

	private void writeDecSapTag(String tag, int value) throws ASAPConversionException
	{
		writeString(tag);
		writeDec(value);
		writeByte('\r');
		writeByte('\n');
	}

	private void writeHexSapTag(String tag, int value) throws ASAPConversionException
	{
		if (value < 0)
			return;
		writeString(tag);
		for (int i = 12; i >= 0; i -= 4) {
			int digit = value >> i & 15;
			writeByte(digit + (digit < 10 ? '0' : 55));
		}
		writeByte('\r');
		writeByte('\n');
	}

	private void writeSapHeader(ASAPInfo info, int type, int init, int player) throws ASAPConversionException
	{
		writeString("SAP\r\n");
		writeTextSapTag("AUTHOR ", info.getAuthor());
		writeTextSapTag("NAME ", info.getTitle());
		writeTextSapTag("DATE ", info.getDate());
		if (info.getSongs() > 1) {
			writeDecSapTag("SONGS ", info.getSongs());
			if (info.getDefaultSong() > 0)
				writeDecSapTag("DEFSONG ", info.getDefaultSong());
		}
		if (info.getChannels() > 1)
			writeString("STEREO\r\n");
		if (info.isNtsc())
			writeString("NTSC\r\n");
		writeString("TYPE ");
		writeByte(type);
		writeByte('\r');
		writeByte('\n');
		if (info.getPlayerRateScanlines() != (type == 'S' ? 78 : 312) || info.isNtsc())
			writeDecSapTag("FASTPLAY ", info.getPlayerRateScanlines());
		if (type == 'C')
			writeHexSapTag("MUSIC ", info.getMusicAddress());
		writeHexSapTag("INIT ", init);
		writeHexSapTag("PLAYER ", player);
		writeHexSapTag("COVOX ", info.getCovoxAddress());
		for (int song = 0; song < info.getSongs(); song++) {
			if (info.getDuration(song) < 0)
				break;
			writeString("TIME ");
			final byte[] s = new byte[9];
			writeBytes(s, 0, durationToString(s, info.getDuration(song)));
			if (info.getLoop(song))
				writeString(" LOOP");
			writeByte('\r');
			writeByte('\n');
		}
	}

	private void writeExecutableHeader(int[] initAndPlayer, ASAPInfo info, int type, int init, int player) throws ASAPConversionException
	{
		if (initAndPlayer == null)
			writeSapHeader(info, type, init, player);
		else {
			initAndPlayer[0] = init;
			initAndPlayer[1] = player;
		}
	}

	private void writePlaTaxLda0() throws ASAPConversionException
	{
		writeByte(104);
		writeByte(170);
		writeByte(169);
		writeByte(0);
	}

	private void writeCmcInit(int[] initAndPlayer, ASAPInfo info) throws ASAPConversionException
	{
		if (initAndPlayer == null)
			return;
		writeWord(4064);
		writeWord(4080);
		writeByte(72);
		int music = info.getMusicAddress();
		writeByte(162);
		writeByte(music & 255);
		writeByte(160);
		writeByte(music >> 8);
		writeByte(169);
		writeByte(112);
		writeByte(32);
		writeWord(initAndPlayer[1] + 3);
		writePlaTaxLda0();
		writeByte(76);
		writeWord(initAndPlayer[1] + 3);
		initAndPlayer[0] = 4064;
		initAndPlayer[1] += 6;
	}

	private void writeExecutableFromSap(int[] initAndPlayer, ASAPInfo info, int type, byte[] module, int moduleLen) throws ASAPConversionException
	{
		writeExecutableHeader(initAndPlayer, info, type, info.getInitAddress(), info.player);
		writeBytes(module, info.headerLen, moduleLen);
	}

	private int writeExecutableHeaderForSongPos(int[] initAndPlayer, ASAPInfo info, int player, int codeForOneSong, int codeForManySongs, int playerOffset) throws ASAPConversionException
	{
		if (info.getSongs() != 1) {
			writeExecutableHeader(initAndPlayer, info, 'B', player - codeForManySongs, player + playerOffset);
			return player - codeForManySongs - info.getSongs();
		}
		writeExecutableHeader(initAndPlayer, info, 'B', player - codeForOneSong, player + playerOffset);
		return player - codeForOneSong;
	}

	final void writeExecutable(int[] initAndPlayer, ASAPInfo info, byte[] module, int moduleLen) throws ASAPConversionException
	{
		byte[] playerRoutine = ASAP6502.getPlayerRoutine(info);
		int player = -1;
		int playerLastByte = -1;
		int music = info.getMusicAddress();
		if (playerRoutine != null) {
			player = ASAPInfo.getWord(playerRoutine, 2);
			playerLastByte = ASAPInfo.getWord(playerRoutine, 4);
			if (music <= playerLastByte)
				throw new ASAPConversionException("Module address conflicts with the player routine");
		}
		int startAddr;
		switch (info.type) {
		case SAP_B:
			writeExecutableFromSap(initAndPlayer, info, 'B', module, moduleLen);
			break;
		case SAP_C:
			writeExecutableFromSap(initAndPlayer, info, 'C', module, moduleLen);
			writeCmcInit(initAndPlayer, info);
			break;
		case SAP_D:
			writeExecutableFromSap(initAndPlayer, info, 'D', module, moduleLen);
			break;
		case SAP_S:
			writeExecutableFromSap(initAndPlayer, info, 'S', module, moduleLen);
			break;
		case CMC:
		case CM3:
		case CMR:
		case CMS:
			writeExecutableHeader(initAndPlayer, info, 'C', -1, player);
			writeWord(65535);
			writeBytes(module, 2, moduleLen);
			writeBytes(playerRoutine, 2, playerLastByte - player + 7);
			writeCmcInit(initAndPlayer, info);
			break;
		case DLT:
			startAddr = writeExecutableHeaderForSongPos(initAndPlayer, info, player, 5, 7, 259);
			if (moduleLen == 11270) {
				writeBytes(module, 0, 4);
				writeWord(19456);
				writeBytes(module, 6, moduleLen);
				writeByte(0);
			}
			else
				writeBytes(module, 0, moduleLen);
			writeWord(startAddr);
			writeWord(playerLastByte);
			if (info.getSongs() != 1) {
				writeBytes(info.songPos, 0, info.getSongs());
				writeByte(170);
				writeByte(188);
				writeWord(startAddr);
			}
			else {
				writeByte(160);
				writeByte(0);
			}
			writeByte(76);
			writeWord(player + 256);
			writeBytes(playerRoutine, 6, playerLastByte - player + 7);
			break;
		case MPT:
			startAddr = writeExecutableHeaderForSongPos(initAndPlayer, info, player, 13, 17, 3);
			writeBytes(module, 0, moduleLen);
			writeWord(startAddr);
			writeWord(playerLastByte);
			if (info.getSongs() != 1) {
				writeBytes(info.songPos, 0, info.getSongs());
				writeByte(72);
			}
			writeByte(160);
			writeByte(music & 255);
			writeByte(162);
			writeByte(music >> 8);
			writeByte(169);
			writeByte(0);
			writeByte(32);
			writeWord(player);
			if (info.getSongs() != 1) {
				writeByte(104);
				writeByte(168);
				writeByte(190);
				writeWord(startAddr);
			}
			else {
				writeByte(162);
				writeByte(0);
			}
			writeByte(169);
			writeByte(2);
			writeBytes(playerRoutine, 6, playerLastByte - player + 7);
			break;
		case RMT:
			writeExecutableHeader(initAndPlayer, info, 'B', 3200, 1539);
			writeBytes(module, 0, ASAPInfo.getWord(module, 4) - music + 7);
			writeWord(3200);
			if (info.getSongs() != 1) {
				writeWord(3210 + info.getSongs());
				writeByte(168);
				writeByte(185);
				writeWord(3211);
			}
			else {
				writeWord(3208);
				writeByte(169);
				writeByte(0);
			}
			writeByte(162);
			writeByte(music & 255);
			writeByte(160);
			writeByte(music >> 8);
			writeByte(76);
			writeWord(1536);
			if (info.getSongs() != 1)
				writeBytes(info.songPos, 0, info.getSongs());
			writeBytes(playerRoutine, 2, playerLastByte - player + 7);
			break;
		case TMC:
			int perFrame = module[37] & 0xff;
			int player2 = player + WRITE_EXECUTABLE_TMC_PLAYER_OFFSET[perFrame - 1];
			startAddr = player2 + WRITE_EXECUTABLE_TMC_INIT_OFFSET[perFrame - 1];
			if (info.getSongs() != 1)
				startAddr -= 3;
			writeExecutableHeader(initAndPlayer, info, 'B', startAddr, player2);
			writeBytes(module, 0, moduleLen);
			writeWord(startAddr);
			writeWord(playerLastByte);
			if (info.getSongs() != 1)
				writeByte(72);
			writeByte(160);
			writeByte(music & 255);
			writeByte(162);
			writeByte(music >> 8);
			writeByte(169);
			writeByte(112);
			writeByte(32);
			writeWord(player);
			if (info.getSongs() != 1)
				writePlaTaxLda0();
			else {
				writeByte(169);
				writeByte(96);
			}
			switch (perFrame) {
			case 2:
				writeByte(6);
				writeByte(0);
				writeByte(76);
				writeWord(player);
				writeByte(165);
				writeByte(0);
				writeByte(230);
				writeByte(0);
				writeByte(74);
				writeByte(144);
				writeByte(5);
				writeByte(176);
				writeByte(6);
				break;
			case 3:
			case 4:
				writeByte(160);
				writeByte(1);
				writeByte(132);
				writeByte(0);
				writeByte(208);
				writeByte(10);
				writeByte(198);
				writeByte(0);
				writeByte(208);
				writeByte(12);
				writeByte(160);
				writeByte(perFrame);
				writeByte(132);
				writeByte(0);
				writeByte(208);
				writeByte(3);
				break;
			default:
				break;
			}
			writeBytes(playerRoutine, 6, playerLastByte - player + 7);
			break;
		case TM2:
			writeExecutableHeader(initAndPlayer, info, 'B', 4992, 2051);
			writeBytes(module, 0, moduleLen);
			writeWord(4992);
			if (info.getSongs() != 1) {
				writeWord(5008);
				writeByte(72);
			}
			else
				writeWord(5006);
			writeByte(160);
			writeByte(music & 255);
			writeByte(162);
			writeByte(music >> 8);
			writeByte(169);
			writeByte(112);
			writeByte(32);
			writeWord(2048);
			if (info.getSongs() != 1)
				writePlaTaxLda0();
			else {
				writeByte(169);
				writeByte(0);
				writeByte(170);
			}
			writeByte(76);
			writeWord(2048);
			writeBytes(playerRoutine, 2, playerLastByte - player + 7);
			break;
		case FC:
			writeExecutableHeader(initAndPlayer, info, 'B', player, player + 3);
			writeWord(65535);
			writeWord(music);
			writeWord(music + moduleLen - 1);
			writeBytes(module, 0, moduleLen);
			writeBytes(playerRoutine, 2, playerLastByte - player + 7);
			break;
		}
	}

	private static final int XEX_INFO_CHARACTERS_PER_LINE = 32;

	private static int padXexInfo(byte[] dest, int offset, int endColumn)
	{
		while (offset % 32 != endColumn)
			dest[offset++] = ' ';
		return offset;
	}

	private static int formatXexInfoText(byte[] dest, int destLen, int endColumn, String src, boolean author)
	{
		int srcLen = src.length();
		for (int srcOffset = 0; srcOffset < srcLen;) {
			int c = src.charAt(srcOffset++);
			if (c == ' ') {
				if (author && srcOffset < srcLen && src.charAt(srcOffset) == '&') {
					int authorLen;
					for (authorLen = 1; srcOffset + authorLen < srcLen; authorLen++) {
						if (src.charAt(srcOffset + authorLen) == ' ' && srcOffset + authorLen + 1 < srcLen && src.charAt(srcOffset + authorLen + 1) == '&')
							break;
					}
					if (authorLen <= 32 && destLen % 32 + 1 + authorLen > 32) {
						destLen = padXexInfo(dest, destLen, 1);
						continue;
					}
				}
				int wordLen;
				for (wordLen = 0; srcOffset + wordLen < srcLen && src.charAt(srcOffset + wordLen) != ' '; wordLen++) {
				}
				if (wordLen <= 32 && destLen % 32 + 1 + wordLen > 32) {
					destLen = padXexInfo(dest, destLen, 0);
					continue;
				}
			}
			dest[destLen++] = (byte) c;
		}
		return padXexInfo(dest, destLen, endColumn);
	}

	private void writeXexInfoTextDl(int address, int len, int verticalScrollAt) throws ASAPConversionException
	{
		writeByte(verticalScrollAt == 0 ? 98 : 66);
		writeWord(address);
		for (int i = 32; i < len; i += 32)
			writeByte(i == verticalScrollAt ? 34 : 2);
	}

	private void writeXexInfo(ASAPInfo info) throws ASAPConversionException
	{
		final byte[] title = new byte[256];
		int titleLen = formatXexInfoText(title, 0, 0, info.getTitle().length() == 0 ? "(untitled)" : info.getTitle(), false);
		final byte[] author = new byte[256];
		int authorLen;
		if (info.getAuthor().length() > 0) {
			author[0] = 'b';
			author[1] = 'y';
			author[2] = ' ';
			authorLen = formatXexInfoText(author, 3, 0, info.getAuthor(), true);
		}
		else
			authorLen = 0;
		final byte[] other = new byte[256];
		int otherLen = formatXexInfoText(other, 0, 19, info.getDate(), false);
		otherLen = formatXexInfoText(other, otherLen, 27, info.getChannels() > 1 ? " STEREO" : "   MONO", false);
		int duration = info.getDuration(info.getDefaultSong());
		if (duration > 0 && secondsToString(other, otherLen, duration + 999))
			otherLen += 5;
		else
			otherLen = padXexInfo(other, otherLen, 0);
		int totalCharacters = titleLen + authorLen + otherLen;
		int totalLines = totalCharacters / 32;
		int otherAddress = 64592 - otherLen;
		int titleAddress = otherAddress - authorLen - 8 - titleLen;
		writeWord(titleAddress);
		writeBytes(FuResource.getByteArray("xexinfo.obx", 178), 4, 6);
		writeBytes(title, 0, titleLen);
		for (int i = 0; i < 8; i++)
			writeByte(85);
		writeBytes(author, 0, authorLen);
		writeBytes(other, 0, otherLen);
		for (int i = totalLines; i < 26; i++)
			writeByte(112);
		writeByte(48);
		writeXexInfoTextDl(titleAddress, titleLen, titleLen - 32);
		writeByte(8);
		writeByte(0);
		for (int i = 0; i < authorLen; i += 32)
			writeByte(2);
		writeByte(16);
		for (int i = 0; i < otherLen; i += 32)
			writeByte(2);
		writeBytes(FuResource.getByteArray("xexinfo.obx", 178), 6, 178);
	}

	private void writeNative(ASAPInfo info, byte[] module, int moduleLen) throws ASAPConversionException
	{
		final ASAPNativeModuleWriter nativeWriter = new ASAPNativeModuleWriter();
		nativeWriter.writer = this;
		nativeWriter.sourceModule = module;
		ASAPModuleType type = info.type;
		switch (type) {
		case SAP_B:
		case SAP_C:
			int offset = info.getRmtSapOffset(module, moduleLen);
			if (offset > 0) {
				nativeWriter.sourceOffset = offset - 2;
				nativeWriter.write(info, ASAPModuleType.RMT, moduleLen - offset + 2);
				return;
			}
			nativeWriter.sourceOffset = info.headerLen;
			int blockLen = nativeWriter.getWord(4) - nativeWriter.getWord(2) + 7;
			if (blockLen < 7 || info.headerLen + blockLen >= moduleLen)
				throw new ASAPConversionException("Cannot extract module from SAP");
			type = info.getOriginalModuleType(module, moduleLen);
			if (type == ASAPModuleType.FC)
				writeBytes(module, info.headerLen + 6, info.headerLen + blockLen);
			else
				nativeWriter.write(info, type, blockLen);
			break;
		case FC:
			writeBytes(module, 0, moduleLen);
			return;
		default:
			nativeWriter.sourceOffset = 0;
			nativeWriter.write(info, type, moduleLen);
			break;
		}
	}

	/**
	 * Writes the given module in a possibly different file format.
	 * @param targetFilename Output filename, used to determine the format.
	 * @param info File information got from the source file with data updated for the output file.
	 * @param module Contents of the source file.
	 * @param moduleLen Length of the source file.
	 * @param tag Display information (xex output only).
	 */
	public final int write(String targetFilename, ASAPInfo info, byte[] module, int moduleLen, boolean tag) throws ASAPConversionException
	{
		int destExt = ASAPInfo.getPackedExt(targetFilename);
		switch (destExt) {
		case 7364979:
			writeExecutable(null, info, module, moduleLen);
			return this.outputOffset;
		case 7890296:
			{
				final int[] initAndPlayer = new int[2];
				writeExecutable(initAndPlayer, info, module, moduleLen);
				switch (info.type) {
				case SAP_D:
					if (info.getPlayerRateScanlines() != 312)
						throw new ASAPConversionException("Impossible conversion");
					writeBytes(FuResource.getByteArray("xexd.obx", 117), 2, 117);
					writeWord(initAndPlayer[0]);
					if (initAndPlayer[1] < 0) {
						writeByte(96);
						writeByte(96);
						writeByte(96);
					}
					else {
						writeByte(76);
						writeWord(initAndPlayer[1]);
					}
					writeByte(info.getDefaultSong());
					break;
				case SAP_S:
					throw new ASAPConversionException("Impossible conversion");
				default:
					writeBytes(FuResource.getByteArray("xexb.obx", 183), 2, 183);
					writeWord(initAndPlayer[0]);
					writeByte(76);
					writeWord(initAndPlayer[1]);
					writeByte(info.getDefaultSong());
					int fastplay = info.getPlayerRateScanlines();
					writeByte(fastplay & 1);
					writeByte((fastplay >> 1) % 156);
					writeByte((fastplay >> 1) % 131);
					writeByte(fastplay / 312);
					writeByte(fastplay / 262);
					break;
				}
				if (tag)
					writeXexInfo(info);
				writeWord(736);
				writeWord(737);
				writeWord(tag ? 256 : 292);
				final FlashPack flashPack = new FlashPack();
				flashPack.compress(this);
				return this.outputOffset;
			}
		default:
			String possibleExt = info.getOriginalModuleExt(module, moduleLen);
			if (possibleExt != null) {
				int packedPossibleExt = ASAPInfo.packExt(possibleExt);
				if (destExt == packedPossibleExt || (destExt == 3698036 && packedPossibleExt == 6516084)) {
					writeNative(info, module, moduleLen);
					return this.outputOffset;
				}
			}
			throw new ASAPConversionException("Impossible conversion");
		}
	}

	private static final int[] WRITE_EXECUTABLE_TMC_PLAYER_OFFSET = { 3, -9, -10, -10 };

	private static final int[] WRITE_EXECUTABLE_TMC_INIT_OFFSET = { -14, -16, -17, -17 };
}
