// Generated automatically with "fut". Do not edit.
package net.sf.asap;

enum ASAPModuleType
{
	SAP_B,
	SAP_C,
	SAP_D,
	SAP_S,
	CMC,
	CM3,
	CMR,
	CMS,
	DLT,
	MPT,
	RMT,
	TMC,
	TM2,
	FC
}
