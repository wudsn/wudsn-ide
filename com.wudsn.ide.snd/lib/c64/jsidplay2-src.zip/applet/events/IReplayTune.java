package applet.events;


/**
 * Replay current tune.
 * 
 * @author Ken
 * 
 */
public interface IReplayTune extends IEvent {
}
