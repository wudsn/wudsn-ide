package applet.events;

/**
 * Event which is called periodically to update a view.
 * 
 * @author Ken
 *
 */
public interface IUpdateUI extends IEvent {

}
