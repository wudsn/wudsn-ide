package applet.events;

/**
 * Just a base interface of all UI events.
 * 
 * @author Ken
 * 
 */
public interface IEvent {

}
