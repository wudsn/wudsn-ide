package applet.events;

/**
 * Stop playing a tune, halt emulation.
 * 
 * @author Ken
 * 
 */
public interface IStopTune extends IEvent {

}
