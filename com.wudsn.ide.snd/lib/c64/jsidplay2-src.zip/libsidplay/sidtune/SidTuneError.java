package libsidplay.sidtune;

@SuppressWarnings("serial")
public class SidTuneError extends Exception {
	public SidTuneError(final String error) {
		super(error);
	}
}
