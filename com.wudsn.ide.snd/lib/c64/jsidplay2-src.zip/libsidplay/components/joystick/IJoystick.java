package libsidplay.components.joystick;

public interface IJoystick {
	byte getValue();
}
