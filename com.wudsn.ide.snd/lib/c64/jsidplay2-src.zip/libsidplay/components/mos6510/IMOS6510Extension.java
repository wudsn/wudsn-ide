package libsidplay.components.mos6510;

public interface IMOS6510Extension {
	void fetch(long time);
}
