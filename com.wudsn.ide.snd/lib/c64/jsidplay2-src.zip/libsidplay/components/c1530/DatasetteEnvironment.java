package libsidplay.components.c1530;

public interface DatasetteEnvironment {
	public boolean getTapeSense();
	public void setMotor(boolean state);
	public void toggleWriteBit(boolean state);
}
