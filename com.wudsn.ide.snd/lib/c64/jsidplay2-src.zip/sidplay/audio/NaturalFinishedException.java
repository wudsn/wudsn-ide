package sidplay.audio;

public class NaturalFinishedException extends InterruptedException {

}
